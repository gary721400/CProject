/*******************************************************************
 * Copyright (c) 2011
 * British Virgin Isiands Billion Gold Securities Ltd.
 * File Name	: apManager.h
 * Author	:
 * Create Date	: MAY 18, 2011
 * History	:
 * Remark	:
*******************************************************************/

#include <sfr.h>
#include "fs.h"
#ifndef	_apmanager_h
#define	_apmanager_h



//WDT
#define	CLEAR_WDT			__asm{BSET RTCWDT.14};	//   bclr pddir.5   movx r0,pdod  xor r0,#0x0020    movx	pdod,r0 };//pd5
#define ENABLE_WDT			RTCWDT = 0xBFFFU;		// Enable watchdog,12M,82ms timeout
#define DISABLE_WDT			__asm{BCLR RTCWDT.15};

#define PUSH_DS0			__asm{PUSH DS0  MOV DS0,#0};
#define POP_DS0				__asm{POP DS0};


#endif
