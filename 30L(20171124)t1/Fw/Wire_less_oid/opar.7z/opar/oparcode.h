#ifndef _OPARCODE_H_
#define _OPARCODE_H_
//-----------------------------------------------------------------------------

//-----------------------------------------------------------------------------
#ifdef __KBCC__
#pragma CODE = OPARCODE_CODE
#pragma DATA = OPARCODE_DATA
#define _NEAR	__X
//#define nearset	memset
#define	_KB_ASM_
#else
#define _NEAR
#define _DEBUG_PC_SW
#define nearset	memset
#endif

//-----------------------------------------------------------------------------
// extern variable
//-----------------------------------------------------------------------------

extern _NEAR unsigned long int DecValue;
extern _NEAR unsigned short int dotcnt;

extern _NEAR unsigned int Bright;

extern char barcode(unsigned char *buf, unsigned int *value);
extern void InitDotExtract(void);

#define	_WIDTH 120
#define	_HEIGHT 120

//*****************************************************************************
// EOF
//*****************************************************************************
#endif//_OPARCODE_H_