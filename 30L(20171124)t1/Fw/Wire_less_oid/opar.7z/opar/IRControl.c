/*******************************************************************
 * Copyright (c) 2010
 * British Virgin Isiands Billion Gold Securities Ltd.
 * File Name    : IRControl.c
 * Author       :
 * Create Date  : Oct. 27, 2010
 * History      :
 * Remark       :
*******************************************************************/
#include <ISD12_DDK.H>
#include <fs.h>
#include <SFR.h>
#include <string.h>
#include "IRControl.h"
//#include "CodeImg.h"

//--------------------------------------------------------------------
#pragma CODE = IR_CODE
#pragma DATA = IR_XRAM
//--------------------------------------------------------------------

//--------------------------------------------------------------------
#pragma CODE = IR_INIT_CODE
//--------------------------------------------------------------------
void IR_Init(void)
{
//	SetVector(0x12,IR_ISR);  //Temer1 interrupt rountine
	__asm
	{
// 		bset TM1ICR.0  //Enable timer1 ISR    //owen Mask For Test
// 		bclr TM1ICR.4
//		bclr TM1ICR.5
        bset PBEN.8
        bset PBEN.9
	}
	PWM4 = 0;
	PWM5 = 0;
	TM1PRD = IR_Max_Cycle;
//  TMR1CR = 0XD060;           // Enable PWM7,PWM6,CLOCK=12MHZ
	TMR1CR = 0XD018;           // Enable PWM4,PWM5,CLOCK=12MHZ
}
//--------------------------------------------------------------------
#pragma CODE = IR_CODE
//--------------------------------------------------------------------
void IR_Close(void)
{
	TMR1CR=0X00;        // Disable Timer1
	__asm
	{
		bclr TM1ICR.0  //disable timer1 ISR
		bclr PBDIR.8
		bclr PBDIR.9
		bset PBOD.8
		bset PBOD.9
	}
}
//--------------------------------------------------------------------
void LeftIR_Level(unsigned int level)
{
	PWM4= level;
}
//--------------------------------------------------------------------
void RightIR_Level(unsigned int level)
{
	PWM5= level;
}
//--------------------------------------------------------------------
//void Delayms(unsigned int ms)  //1ms for 80MHZ
//{
//	int mscount,timecount = 0;
//	for(timecount=0;timecount<ms;timecount++)
//		for(mscount=0;mscount<=6400;mscount++)
//		{
//			;
//		}
//}
//--------------------------------------------------------------------
