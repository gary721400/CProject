
#include "mbc_decode.h"
#if PLAT_FORM_TYPE == PLAT_FORM_PC
#include <stdio.h>
#include <stdlib.h>
#if COMPILER_TYPE == COMPILER_CPP_BUILDER
#include "UnitMyG.h"
#endif
#endif

#if PLAT_FORM_TYPE == PLAT_FORM_KB
#pragma DATA = MBC_DECODE_DATA
#pragma CODE = MBC_DECODE_CODE
#endif

#if PLAT_FORM_TYPE == PLAT_FORM_PC
U8	g_raw_data[MAX_IMAGE_HEIGHT][MAX_IMAGE_WIDTH];
#endif

__X Seg	g_seg[MAX_DOTS_PER_LINE];
__X DOT8	g_exaction_dots[MAX_DOTS_NUM];
__X U8	g_dots_count;

__X U16	g_old_value;
__X U16 g_old_check;

#if PLAT_FORM_TYPE == PLAT_FORM_PC
#if COMPILER_TYPE == COMPILER_VISUAL_CPP
#define	CODE_TABLE_NAME	"sonix_20120218.bin"
FILE*	g_code_table = NULL;
#endif
#endif

#if USE_ARG_MACRO == FALSE
U8	IMAGE_TYPE =	IMAGE_120x120;
U8	IMAGE_WIDTH =	120;
U8	IMAGE_HEIGHT = 120;
//��С��Ĵ�С
U8	MIN_DOT_WIDTH = 2;
U8	MAX_DOT_WIDTH = 6;
U8	MIN_DOT_HEIGHT = 2;
U8	MAX_DOT_HEIGHT = 8;

U8	DIST_GRID = 18;

//Y����ϵ��Ǹ��ؼ���ƫ�Χ
U8	OFFSET_KEY_DOT = 7;

//�����ת90���Ժ�Ѱ����һ����ƫ�Χ
U8	OFFSET_AXIS_DOT = 3;

//��������ͬһֱ�ߵ�ƫ�Χ
U8	OFFSET_AXIS_ADJ = 2;

//X,Y�ύ�ǵ�ƫ�Χ�������ֵ���ǽǶ�ֵ���ǲ����ǶȵĲο�ֵ
U16	OFFSET_AXIS_ANGLE = 200;

//���ݵ�ƫ������������ܷ�Χ
U8	OFFSET_DATA_DOT = 7;

//X,Y���ϴ���ͬһֱ�ߵ������ƫ����Сֵ 
U8	OFFSET_AXIS_LINE_MIN = 1;

//X,Y���ϴ���ͬһֱ�ߵ������ƫ�����ֵ 
U8	OFFSET_AXIS_LINE_MAX = 3;

//X,Y���ϴ���ͬһֱ�߽Ƕȵ�ƫ��
U16	OFFSET_AXIS_LINE_ANGLE = 710;

//Y���Ϲؼ���ľ���Y�ḽ������ƫ��Ƕ�
U16	OFFSET_KEY_VEC_ANGLE = 710;

Bool	CHANGE_ARGS(U8 type)
{
	if(type == IMAGE_120x120)
	{
		IMAGE_TYPE =	IMAGE_120x120;
		IMAGE_WIDTH =	120;
		IMAGE_HEIGHT = 120;
		MIN_DOT_WIDTH = 2;
		MAX_DOT_WIDTH = 8;
		MIN_DOT_HEIGHT = 2;
		MAX_DOT_HEIGHT = 8;
		DIST_GRID = 18;
		OFFSET_KEY_DOT = 7;
		OFFSET_AXIS_DOT = 3;
		OFFSET_AXIS_ADJ = 2;
		OFFSET_AXIS_ANGLE = 200;
		OFFSET_DATA_DOT = 7;
		OFFSET_AXIS_LINE_MIN = 1;
		OFFSET_AXIS_LINE_MAX = 3;
		OFFSET_AXIS_LINE_ANGLE = 710;
		OFFSET_KEY_VEC_ANGLE = 710;
		g_hash_info.width = IMAGE_WIDTH;
		g_hash_info.hash_num = IMAGE_HEIGHT;
	}
	else if(type == IMAGE_128x128)
	{
		IMAGE_TYPE =	IMAGE_128x128;
		IMAGE_WIDTH =	128;
		IMAGE_HEIGHT = 128;
		MIN_DOT_WIDTH = 2;
		MAX_DOT_WIDTH = 8;
		MIN_DOT_HEIGHT = 2;
		MAX_DOT_HEIGHT = 8;
		DIST_GRID = 18;
		OFFSET_KEY_DOT = 7;
		OFFSET_AXIS_DOT = 3;
		OFFSET_AXIS_ADJ = 2;
		OFFSET_AXIS_ANGLE = 200;
		OFFSET_DATA_DOT = 7;
		OFFSET_AXIS_LINE_MIN = 1;
		OFFSET_AXIS_LINE_MAX = 3;
		OFFSET_AXIS_LINE_ANGLE = 710;
		OFFSET_KEY_VEC_ANGLE = 710;
		g_hash_info.width = IMAGE_WIDTH;
		g_hash_info.hash_num = IMAGE_HEIGHT;
	}
	else if(type == IMAGE_240x240)
	{
		IMAGE_TYPE = IMAGE_240x240;
		IMAGE_WIDTH = 240;
		IMAGE_HEIGHT = 240;
		MIN_DOT_WIDTH = 4;
		MAX_DOT_WIDTH = 24;
		MIN_DOT_HEIGHT = 4;
		MAX_DOT_HEIGHT = 14;
		DIST_GRID = 40;
		OFFSET_KEY_DOT = 14;
		OFFSET_AXIS_DOT = 6;
		OFFSET_AXIS_ADJ = 4;
		OFFSET_AXIS_ANGLE  = 200;
		OFFSET_DATA_DOT = 14;
		OFFSET_AXIS_LINE_MIN = 3;
		OFFSET_AXIS_LINE_MAX = 6;
		OFFSET_AXIS_LINE_ANGLE = 710;
		g_hash_info.width = IMAGE_WIDTH;
		g_hash_info.hash_num = IMAGE_HEIGHT;
	}
	else if(type == IMAGE_170x170)
	{
		IMAGE_TYPE = IMAGE_170x170;
		IMAGE_WIDTH = 170;
		IMAGE_HEIGHT = 170;
		MIN_DOT_WIDTH = 4;
		MAX_DOT_WIDTH = 24;
		MIN_DOT_HEIGHT = 4;
		MAX_DOT_HEIGHT = 14;
		DIST_GRID = 40;
		OFFSET_KEY_DOT = 14;
		OFFSET_AXIS_DOT = 6;
		OFFSET_AXIS_ADJ = 4;
		OFFSET_AXIS_ANGLE  = 200;
		OFFSET_DATA_DOT = 14;
		OFFSET_AXIS_LINE_MIN = 3;
		OFFSET_AXIS_LINE_MAX = 6;
		OFFSET_AXIS_LINE_ANGLE = 710;
		OFFSET_KEY_VEC_ANGLE = 710;
		g_hash_info.width = IMAGE_WIDTH;
		g_hash_info.hash_num = IMAGE_HEIGHT;
	}
	else
		return	FALSE;
	return	TRUE;
}

#endif


#pragma CODE = DO_LINE_DOT_CODE

//����������Ҫ���⴦��
Bool init_raw_data( void )
{
   S16 iter;
   g_dots_count = 0;
   for( iter = 0; iter < numof( g_seg ); ++iter )
      g_seg[ iter ].count = 0;

#if PLAT_FORM_TYPE == PLAT_FORM_PC
#if COMPILER_TYPE == COMPILER_VISUAL_CPP
 	g_code_table = fopen(CODE_TABLE_NAME,"rb");
#elif COMPILER_TYPE == COMPILER_CPP_BUILDER
//	g_code_table = fopen(sFilePathName,"rb");
#endif
#endif
   return TRUE;
}

#if 0
U16	search_code_table(U16 num)
{
#if PLAT_FORM_TYPE == PLAT_FORM_PC
#if COMPILER_TYPE == COMPILER_VISUAL_CPP
	U8	buf[2];
	if(g_code_table==NULL)
		return	num;
	fseek(g_code_table,((U32)num)*2,SEEK_SET);
	fread(buf,1,sizeof(buf),g_code_table);
	num = (((U16)buf[0])<<8);
	num += buf[1];
	return	num;
#elif COMPILER_TYPE == COMPILER_CPP_BUILDER
	U32 Position=num;
	Position=Position<<1;
	num=((U16)pBinbuf[Position])<<8;
	num+=pBinbuf[Position+1];
	return	num;
#endif
#endif

   return num;
}

/*U8*/void get_line_dots(U8 iy, __X U8 * line);


U8	get_dots( void )
{
#if PLAT_FORM_TYPE == PLAT_FORM_PC
	U8	iter;
	U16 y;
	g_dots_count = 0;
	for(iter=0;iter<numof(g_seg);++iter)
		g_seg[iter].count = 0;
	for(y=0;y<IMAGE_HEIGHT;++y)
	{
		get_line_dots(y,g_raw_data[y]);
		if(g_dots_count == MAX_DOTS_NUM)
			break;
	}
#endif
	return	g_dots_count;
}
#endif


#pragma CODE = MBC_DECODE_CODE

DOT dot8_to_dot16( DOT8 *d )
{
   DOT r;
   r.X = d->X;
   r.Y = d->Y;
   return r;
}


#ifdef GET_LINE_DOTS_C
DOT8 dot16_to_dot8( DOT *d )
{
   DOT8 r;
   r.X = ( U8 )d->X;
   r.Y = ( U8 )d->Y;
   return r;
}
#endif   //#ifdef GET_LINE_DOTS_C


#if 0
//���ر�Ե��⣬Ҳ���ǲ�ֻ���ƫ���ؾ���1�ı�Ե
//���ؾ���Ϊ2��ͬ�����
#define	MULT_EDGE_DETECT	1

//��С�Ҷ�ֵMIN_GRAY����������Ҷȵĵ��������������Ե���
#define	MIN_GRAY	35

#define TH_SHIFT	3

U8	get_line_dots(U8 iy,__X U8 * line)
{
	DOT	cur_dot;
	Seg	*	cur_seg;
	U8 ix;
	U8	left,right;
	U8	max_r;
	U8	width;
	U8	height;
	U8 i_near;
	U8	empty;
	U8 iter;                                 
	U8	step;
	U8	count_dots;
	U8	l1,l2;
#if MULT_EDGE_DETECT == 1
	U8	l3;
#endif
#if  USE_ARG_MACRO == FALSE
	U8	of1,of2;
#endif

#if USE_ARG_MACRO == FALSE
	if(IMAGE_TYPE == IMAGE_120x120)
	{
		of1 = 1;
		of2 = 2;
	}
	else
	{
		of1 = 2;
		of2 = 4;
	}
#else
	#if IMAGE_TYPE == IMAGE_120x120
		#define	of1	1
		#define	of2	2
	#else
		#define	of1	2
		#define	of2	4
	#endif
#endif

	step = 0;
	ix = 0;
	left = right = 0;
	count_dots = 0;
	if(g_dots_count>=MAX_DOTS_NUM)
		return 0;
	for(iter=0;iter<numof(g_seg);++iter)
		g_seg[iter].update = 0;
	max_r = IMAGE_WIDTH - of2;
	for(ix=0;ix<max_r;++ix)
	{
		l1 = line[ix];
		l2 = line[ix+of1];
#if MULT_EDGE_DETECT == 1
		l3 = line[ix+of2];
#endif
		if(step==0)
		{
		//	if(line[ix]*7/8>line[ix+1])
		//	if(line[ix]-line[ix+1]>line[ix]/8)
			if(l1>MIN_GRAY)
			{
				if((l1>l2&&(l1-l2)>(l1>>TH_SHIFT))
#if MULT_EDGE_DETECT ==1
					||(l1>l3&&(l1-l3)>(l1>>TH_SHIFT))
#endif
					)
				{
					left = ix;
					step = 1;
				}
			}
		}
		else
		{
			// ������ұ߽��������̣��ͺ���
			if(ix>=left+MAX_DOT_WIDTH)
			{
				left = right = 0;
				step = 0;
				continue;
			}
		//	if(line[ix]<line[ix+1]*7/8)
		//	if(line[ix+1]-line[ix]>(line[ix+1]/8))
		//	if(gr>gl&&gr>MIN_GRAY&&gr-gl>(gr>>3))
			if(l2>l1&&l2>MIN_GRAY&&(l2-l1)>(l2>>TH_SHIFT))
			{
				right = ix+of1;
				step = 0;
			}
#if MULT_EDGE_DETECT == 1
			else if(l3>l1&&l3>MIN_GRAY&&(l3-l1)>(l3>>TH_SHIFT))
			{
				right = ix+of2;
				step = 0;
			}
#endif
			if(step == 0)
			{
#if 0
				if(right<left+MIN_DOT_WIDTH)
				{
					left = right = 0;
					continue;
				}
#endif
				// ������ұ߽��������̣��ͺ���
				for(i_near=0,empty=0xFF;i_near<numof(g_seg);++i_near)
				{
					cur_seg = &g_seg[i_near];
					if(cur_seg->count>0)
					{
						if(!(right<cur_seg->left||left>cur_seg->right))
						{
							break;
						}
					}
					else if(empty == 0xFF)
						empty = i_near;
				}
				if(i_near==numof(g_seg)&&empty!=0xFF)
				{
					cur_seg = &g_seg[empty];
					cur_seg->count = 0;
					cur_seg->gray = 0xFF;
					cur_seg->left = IMAGE_WIDTH;
					cur_seg->right = 0;
					cur_seg->top = iy;
					cur_seg->bottom = iy+1;
					i_near = empty;
				}
				if(i_near!=numof(g_seg))
				{
				//	if(g_seg[i_near].count>=MAX_DOT_HEIGHT)
				//		continue;
					cur_seg = &g_seg[i_near];
					cur_dot.Y = iy;
					cur_seg->update = 1;
					if(left<cur_seg->left)
						cur_seg->left = left;
					if(right>cur_seg->right)
						cur_seg->right = right;
					cur_seg->bottom = iy+1;
					for(iter=left+1;iter<right;++iter)
					{
						cur_dot.X = iter;
						if(line[iter]<cur_seg->gray)
						{
							cur_seg->gray = line[iter];
							cur_seg->dots[0] = cur_dot;
							cur_seg->count = 1;
						}
						else if(line[iter] == cur_seg->gray)
						{
							if(cur_seg->count == 0)
							{
								cur_seg->gray = line[iter];
								cur_seg->dots[0] = cur_dot;
								cur_seg->count = 1;
							}
							else
							{
								cur_seg->dots[1] = cur_dot;
								cur_seg->count = 2;
							}
						}
					}
				}
			}
		}
	}
	
//	if(ix==IMAGE_WIDTH-margin&&step == 1)
//	{
//		right = ix;
//	}
	for(iter=0;iter<numof(g_seg);++iter)
	{
		cur_seg = &g_seg[iter];
		if(cur_seg->count!=0&&cur_seg->update==0)
		{
#if 1
			width = cur_seg->right - cur_seg->left;
			height = cur_seg->bottom - cur_seg->top;
			if(	
				width<MIN_DOT_WIDTH||
			//	width>MAX_DOT_WIDTH||
				height<MIN_DOT_HEIGHT//||
			//	height>MAX_DOT_HEIGHT
				)
			{
				cur_seg->count = 0;
				cur_seg->gray = 0xFF;
				continue;
			}
#endif
			if(cur_seg->count == 1)
				cur_dot = cur_seg->dots[0];
			else
			{
				cur_dot.X = (cur_seg->dots[0].X + cur_seg->dots[1].X)/2;
				cur_dot.Y = (cur_seg->dots[0].Y + cur_seg->dots[1].Y)/2;
			}
			
			g_exaction_dots[g_dots_count]=dot16_to_dot8(&cur_dot);
			++g_dots_count;
			++count_dots;
			cur_seg->count = 0;
			cur_seg->gray = 0xFF;
			if(g_dots_count==MAX_DOTS_NUM)
				return	count_dots;
		}
	}
	return count_dots;
#if	USE_ARG_MACRO == TRUE
	#undef	of2
	#undef	of1
#endif
}
#endif


//DOT	g_dots[MAX_DOTS_NUM];
__X   U8       g_hash_top[ MAX_IMAGE_HEIGHT ];
__X   U8       g_hash_floor[ MAX_IMAGE_HEIGHT ];
//HashInfo	g_hash_info = {g_dots,sizeof(g_dots)/sizeof(g_dots[0]),g_hash_top,g_hash_floor,IMAGE_HEIGHT};
__X   HashInfo g_hash_info = { g_exaction_dots, g_hash_top, g_hash_floor, IMAGE_HEIGHT, IMAGE_WIDTH, numof( g_exaction_dots )};


Bool build_hash_info( HashInfo *hash_info )
{
	DOT8 temp, temp1;
	S16 iter,i_t;
	S16 m;
	if(hash_info->dots == 0||hash_info->dots_num==0||hash_info->hash_floor==0||hash_info->hash_top==0||hash_info->hash_num==0)
		return	0;
	for(iter=0;iter<hash_info->hash_num;++iter)
	{
		hash_info->hash_top[iter] = hash_info->hash_num-1;
		hash_info->hash_floor[iter] = 0;
	}

	for(iter=0;iter<hash_info->dots_num-1;++iter)
	{
		m = iter;
		for(i_t=iter+1;i_t<hash_info->dots_num;++i_t)
		{
			if(hash_info->dots[i_t].Y<hash_info->dots[m].Y
				//||(hash_info->dots[i_t].Y==hash_info->dots[m].Y&&hash_info->dots[i_t].X<hash_info->dots[m].X)
				)
				m = i_t;
		}

		if(m!=iter)
		{
			temp = hash_info->dots[iter];
			//hash_info->dots[iter] = hash_info->dots[m];
			temp1 = hash_info->dots[m];
         hash_info->dots[iter] = temp1;
         
			hash_info->dots[m] = temp;
		}
	}

	for(iter=0,m=-1,i_t =0;iter<hash_info->dots_num;++iter)
	{
		if(m<hash_info->dots[iter].Y/* || m == 0xFF*/)
		{
			m = hash_info->dots[iter].Y;
			while(i_t<=m)
			{
				hash_info->hash_top[i_t++]=iter;
			}
		}
	}
	if(iter==hash_info->dots_num)
		while(i_t<hash_info->hash_num)
			hash_info->hash_top[i_t++]=hash_info->dots_num-1;
	for(iter=hash_info->dots_num-1,i_t=hash_info->hash_num-1,m=0;iter>=0;--iter)
	{
		if(m!=hash_info->dots[iter].Y)
		{
			m = hash_info->dots[iter].Y;
			while(i_t>=m)
			{
				hash_info->hash_floor[i_t--]=iter;
			}
		}
	}
	return 1;
}


#if 0
S16	get_index(HashInfo * hash_info,DOT* dot)
{
	S16	l,r;
	l = hash_info->hash_top[dot->Y];
	r = hash_info->hash_floor[dot->y];
	for(;l<=r;++l)
		if(dot->X==hash_info->dots[l].X)
			return	l;
	return	l;
}
#endif


U16 dist_square(DOT * d1,DOT* d2)
{
	U16 dx,dy;
	if(d2->X>d1->X)
		dx = d2->X - d1->X;
	else
		dx = d1->X - d2->X;
	if(d2->Y>d1->Y)
		dy = d2->Y - d1->Y;
	else
		dy = d1->Y - d2->Y;
	return	dx*dx+dy*dy;
}


U8	get_close_dots_dist(HashInfo * hash_info,DOT* dot_in,DOT* dots_out,int max_num,int distance)
{
	DOT	dot_t;
	S16 iter;
	S16	l,r;
	U8	count = 0;
	if(dot_in->Y<0||dot_in->X<0||dot_in->Y>=hash_info->hash_num||dot_in->X>=hash_info->width)	//Խ��
		return	0;
	if(distance>dot_in->Y)
		l = hash_info->hash_top[0];
	else
		l = hash_info->hash_top[dot_in->Y-distance];
	if(distance+dot_in->Y>=hash_info->hash_num)
		r = hash_info->hash_floor[hash_info->hash_num-1];
	else
		r = hash_info->hash_floor[dot_in->Y+distance];
	if(l>r)
		return	0;
//	else if(l==r)
//		return	get_close_dot(hash_info,dot_in,dots_out);
	else
	{
		distance*=distance;
		for(iter=l;iter<=r;++iter)
		{
		//	if(dot_in->X==hash_info->dots[iter].X&&dot_in->Y==hash_info->dots[iter].Y)
		//		continue;
			dot_t = dot8_to_dot16(&hash_info->dots[iter]);
			if(dist_square(dot_in,&dot_t)<=distance)
			{
				if(dots_out == 0||max_num == 0)
					++count;
				else
				{
					dots_out[count++] = dot_t;
					if(count == max_num)
						break;
				}
			}
		}
	}
	return	count;
}


//distance��Χ��������Ǹ��㣻
U8	get_close_dot(HashInfo * hash_info,DOT* dot_in,DOT* dot_out,U16 distance)
{
	DOT	dot_t;
	S16	l,r;
	U16 md;
	U16 d;
	S16 mi;
	U8 count;
	if(dot_in->Y<0||dot_in->X<0||dot_in->Y>=hash_info->hash_num||dot_in->X>=hash_info->width)	//Խ��
		return	0;
	if(distance>dot_in->Y)
		l = hash_info->hash_top[0];
	else
		l = hash_info->hash_top[dot_in->Y-distance];
	if(distance+dot_in->Y>=hash_info->hash_num)
		r = hash_info->hash_floor[hash_info->hash_num-1];
	else
		r = hash_info->hash_floor[dot_in->Y+distance];
	if(l>r)
	{
		dot_out->X = dot_out->Y = 0;
		return	FALSE;
	}
	md = 0xFFFF;
	mi = l;
	count = 0;
	distance*=distance;
	for(;l<=r;++l)
	{
		dot_t = dot8_to_dot16(&hash_info->dots[l]);
		d=dist_square(&dot_t,dot_in);
		if(d<md)
		{
			md = d;
			mi = l;
		}
		if(d<=distance)
			++count;
	}
	if(md>distance)
		return	count;
	*dot_out = dot8_to_dot16(&hash_info->dots[mi]);
	return	count;
}


__X   AXIS  g_axis;


S16	equal_adj(S16 a,S16 b,U16 adj)
{
	if(a>b)
	{
		if(a-b<=adj)
			return	1;
	}
	else
	{
		if(b-a<=adj)
			return	1;
	}
	return	0;
}


Bool	in_range(DOT* d)
{
	if(d->X==0&&d->Y==0)
		return	FALSE;
	return	(d->X>=0&&d->X<IMAGE_WIDTH&&d->Y>=0&&d->Y<IMAGE_HEIGHT);
}


Bool	in_edge(DOT* d)
{
	if(d->X==0&&d->Y==0)
		return	FALSE;
	if(!in_range(d))
		return	FALSE;
	if((d->X>=(OFFSET_AXIS_LINE_MAX*2)&&d->X<(IMAGE_WIDTH-OFFSET_AXIS_LINE_MAX*2))&&
		(d->Y>=(OFFSET_AXIS_LINE_MAX*2)&&d->Y<(IMAGE_WIDTH-OFFSET_AXIS_LINE_MAX*2)))
		return	FALSE;
	return	TRUE;
}


VECTOR	vec_get(DOT* from,DOT* to)
{
	VECTOR	v;
	v.X = to->X - from->X;
	v.Y = to->Y - from->Y;
	return	v;
}


VECTOR	vec_rotate_90(VECTOR* from,Bool inverse)
{
	VECTOR	v;
	if(!inverse)
	{
		v.Y = from->X;
		v.X = -from->Y;
	}
	else
	{
		v.Y = -from->X;
		v.X = from->Y;
	}
	return	v;
}


VECTOR	vec_neg(VECTOR* v)
{
	VECTOR	r;
	r.X = -v->X;
	r.Y = -v->Y;
	return	r;
}


U16	Sqrt(U16 v);

U16	vec_len(VECTOR* v)
{
	return	Sqrt(v->X*v->X+v->Y*v->Y);
}


DOT	dot_add(DOT* dv,VECTOR* v)
{
	DOT	r;
	r.X = dv->X + v->X;
	r.Y = dv->Y + v->Y;
	return	r;
}


Bool	dot_quad(DOT* origin,DOT * d1,DOT * d2,DOT* new_dot)
{
	new_dot->X = d1->X+d2->X - origin->X;
	new_dot->Y = d1->Y+d2->Y - origin->Y;
	if(!in_range(new_dot))
		return	FALSE;
	return	TRUE;
}


Bool	is_mid(DOT* l,DOT* m,DOT* r,U16 adj)
{
	return	equal_adj(l->X-m->X,m->X-r->X,adj)&&
			equal_adj(l->Y-m->Y,m->Y-r->Y,adj);
}


U16	abs_t(S16 v)
{
	if(v<0)
		return	(-v);
	else
		return	v;
}


typedef enum	_AXIS_TYPE
{
	AXIS_NONE = 0	//���ȱʧ
	,AXIS_X		//ΪX���
	,AXIS_Y		//ΪY���
	,AXIS_ERR	//�������
}AXIS_TYPE;

//originԭ��
//dots_out��ԭ��Ϊ������dots_out[0]Ϊ��һ��㣬������Ѱ���������
//dots_num����ܸ���
//key_vec  Y��ڶ����� ����㣬����еĻ���
AXIS_TYPE	get_axis_dots(HashInfo* hi,DOT * origin,DOT* dots_out,U8* dots_num,VECTOR* key_vec)
{
	VECTOR	last_vec;
	VECTOR	vt;
	DOT	new_dot;
	DOT dot_t;
	S16 iter;
	AXIS_TYPE	type = AXIS_NONE;
	U16 angle;
	U8 result;
	if(key_vec)
	{
		key_vec->X=0;	key_vec->Y=0;
	}
	if(dots_num)
		*dots_num = 1;
	last_vec = vec_get(origin,&dots_out[0]);
	for(iter=1;iter<MAX_AXIS_DOTS_NUM;++iter)
	{
		new_dot=dot_add(&dots_out[iter-1],&last_vec);
		if(!in_range(&new_dot))
			break;
		if(!get_close_dot(hi,&new_dot,&dot_t,OFFSET_KEY_DOT))
		{
#if 0
			if(type == AXIS_Y)
			{
				type = AXIS_ERR;
			}
			else if(type == AXIS_X)
			{
				type = AXIS_NONE;
			}
#endif
			if(in_edge(&new_dot))
				type = AXIS_NONE;
			else
				type = AXIS_ERR;
			break;
		}
		vt = vec_get(&new_dot,&dot_t);
		angle = abs_t(GetAngle(&last_vec,&vt));
		if(iter==1)
		{
			if((abs_t(vt.X)<=OFFSET_AXIS_LINE_MIN&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MIN)||
			(abs_t(vt.X)<=OFFSET_AXIS_LINE_MAX&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MAX&&angle>OFFSET_AXIS_LINE_ANGLE))	//������ͬһֱ��
			{
				type = AXIS_X;
				dots_out[iter] = dot_t;
				if(dots_num)
					(*dots_num)++;
				last_vec = vec_get(&dots_out[iter-1],&dot_t);
			}
			else	 if(angle<=OFFSET_AXIS_LINE_ANGLE)//���ƴ�ֱ������Ϊ��Sonix��Y������
			{
				type = AXIS_Y;
				if(key_vec)
				{
					*key_vec = vt;
				}
				dots_out[iter] = new_dot;
				if(dots_num)
					(*dots_num)++;
				last_vec = vec_get(&dots_out[iter-1],&new_dot);
			}
		}
		else
		{
			if(type == AXIS_X)
			{
				if((abs_t(vt.X)<=OFFSET_AXIS_LINE_MIN&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MIN)||
				(abs_t(vt.X)<=OFFSET_AXIS_LINE_MAX&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MAX&&angle>OFFSET_AXIS_LINE_ANGLE))	//������ͬһֱ��
				{
					dots_out[iter] = dot_t;
					if(dots_num)
						(*dots_num)++;
					last_vec = vec_get(&dots_out[iter-1],&dot_t);
				}
				else
				{
					type = AXIS_ERR;
					break;
				}
			}
			else
			{
				result = FALSE;
				if(abs_t(vt.X)<=OFFSET_AXIS_LINE_MIN&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MIN)
					result = TRUE;
				else
				{
					if(abs_t(vt.X)<=OFFSET_AXIS_LINE_MAX+1&&abs_t(vt.Y)<=OFFSET_AXIS_LINE_MAX+1)
					{
						result=TRUE;
					}
				}
				if(result)
				{
					dots_out[iter] = dot_t;
					if(dots_num)
						(*dots_num)++;
					last_vec = vec_get(&dots_out[iter-1],&dot_t);
				}
				else
				{
					type = AXIS_ERR;
					break;
				}
			}
		}
#if 0
		if(abs_t(vt.X)<=1&&abs_t(vt.Y)<=1)
		{
			if(iter==1)
				type = AXIS_X;
			dots_out[iter] = dot_t;
			last_vec = vec_get(&dots_out[iter-1],&dots_out[iter]);
		}
		else
		{
			if(iter==1)
			{
				type = AXIS_Y;
				dots_out[iter] = new_dot;
				last_vec = vec_get(&dots_out[iter-1],&dots_out[iter]);
				if(key_vec)	*key_vec = vt;
			}
			else
			{
			//	type = AXIS_NONE;
				break;
			}
		}
#endif
	}
	return	type;
}


S16 GetAngle (VECTOR* pvec1,VECTOR* pvec2);

void memset_v(U8 * p,U8 v,U16 size)
{
	while(size--)
		*p++=v;
}


__X U8   g_shift = 0;	//��������ֱ����·����ҵ㣬shift�����л�����
__X S16  g_up,g_down;


Bool	check_axis(HashInfo * hi,AXIS* axis)
{
	VECTOR	cross[4];
	VECTOR	key_v;
	VECTOR	kv_s[4];	//���������洢
	DOT	dots_near[9];
	DOT	axis_dots[4][3];
	DOT	dot_new;
	DOT	dot_t;
	DOT	result;
	DOT	o_d;
	DOT* origin;
	S16	iter,il,ir,it;
	U8	dots_num;
	U8	ckv = 0;		//���������ܵĸ���
	U8	axis_type[4]={0,0,0,0};
	U8	axis_count[4] = {0,0,0,0};
	S8	ax,ay;
	U8	type;

//	g_up=hi->dots_num/2;
//	g_down = g_up+1;
	while(g_up>=0||g_down<hi->dots_num)
	{
		if(g_up>=0&&g_shift==0)
		{
			iter = g_up;
			--g_up;
			g_shift=!g_shift;
		}
		else if(g_down<hi->dots_num&&g_shift==1)
		{
			iter = g_down;
			++g_down;
			g_shift=!g_shift;
		}
		else
		{
			g_shift=!g_shift;
			continue;
		}
		o_d = dot8_to_dot16(&hi->dots[iter]);
		origin = &o_d;
		//�����õĴ���
		//{{
			/*int	d;
			if(origin->X == 79&&origin->Y == 120)
			{
				d= 0;
			}*/
		//}}
		dots_num=get_close_dots_dist(hi,origin,dots_near,numof(dots_near),DIST_GRID+1);
		if(dots_num<3)
			continue;
		for(il = 0;il<dots_num;++il)
		{
			if(origin->X==dots_near[il].X&&origin->Y==dots_near[il].Y)
				continue;
			for(ir=il+1;ir<dots_num;++ir)
			{
				//����������һ�ߵ�������
				if(origin->X==dots_near[ir].X&&origin->Y==dots_near[ir].Y)
					continue;

				cross[0] = vec_get(origin,&dots_near[il]);
				cross[1] = vec_get(origin,&dots_near[ir]);
				if(abs_t(GetAngle(&cross[0],&cross[1]))>OFFSET_AXIS_ANGLE)	//����ֱ��
					continue;
				if(!equal_adj(vec_len(&cross[0]),vec_len(&cross[1]),OFFSET_AXIS_DOT))	//�������Ƴ�
					continue;
				key_v = vec_rotate_90(&cross[0],FALSE);
				if(GetAngle(&key_v, &cross[1])<0)	//˵��cross[0]��cross[1]�ǳɸ�90�ȵģ����Ե���λ��
				{
					key_v = cross[0];
					cross[0] = cross[1];
					cross[1] = key_v;
				}

				cross[2] = vec_neg(&cross[0]);		//cross����originΪ���ĵ�ʮ������
				cross[3] = vec_neg(&cross[1]);
				memset_v((U8 *)axis_dots,0,sizeof(axis_dots));
#if 1
				for(it=0;it<4;++it)					//��ʮ��������ȡʮ�����
				{
					dot_new = dot_add(origin,&cross[it]);
					if(!in_range(&dot_new))
						continue;
					if(!get_close_dot(hi,&dot_new,&result,OFFSET_AXIS_DOT))
						break;
					axis_dots[it][0] = result;
					cross[it] = vec_get(origin,&result);
				}
				if(it<4)	//���ڱ߽紦����ʮ����ȱʧ
					continue;
				//ʮ�������ĵ��Ƿ���
				if(in_range(&axis_dots[2][0]))
				{
					if(!is_mid(&axis_dots[0][0],origin,&axis_dots[2][0],OFFSET_AXIS_ADJ))
						continue;
				}
				if(in_range(&axis_dots[3][0]))
				{
					if(!is_mid(&axis_dots[1][0],origin,&axis_dots[3][0],OFFSET_AXIS_ADJ))
						continue;
				}
#endif
#if 0
				for(it=0;it<4;++it)					//��ʮ��������ȡʮ�����
				{
					dot_new = dot_add(origin,&cross[it]);
					if(!in_range(&dot_new))
						continue;
					if(!get_close_dot(hi,&dot_new,&result,OFFSET_AXIS_DOT))
						continue;
					axis_dots[it][0] = result;
					cross[it] = vec_get(origin,&result);
				}
				if(it<4)	//���ڱ߽紦����ʮ����ȱʧ
					continue;
				//ʮ�������ĵ��Ƿ���
				if(in_range(&axis_dots[2][0]))
				{
					if(!is_mid(&axis_dots[0][0],origin,&axis_dots[2][0],OFFSET_AXIS_ADJ))
					{
						axis_dots[2][0].X = 0;
						axis_dots[2][0].Y = 0;
					}
				}
				if(in_range(&axis_dots[3][0]))
				{
					if(!is_mid(&axis_dots[1][0],origin,&axis_dots[3][0],OFFSET_AXIS_ADJ))
					{
						axis_dots[3][0].X = 0;
						axis_dots[3][0].Y = 0;
					}
				}
#endif
			//	if(!equal_adj(GetAngle(&cross[0],&cross[1]),GetAngle(&cross[2],&cross[3]),OFFSET_AXIS_ANGLE))
			//		continue;

				//��ʮ��Ϊ��׼����ȡ���п����ҵ�����㣻
				ckv = 0;
				for(it=0;it<4;++it)
				{
					axis_type[it] = AXIS_NONE;
					axis_count[it] = 0;
					if(!in_range(&axis_dots[it][0]))
						continue;
					axis_type[it] = get_axis_dots(hi,origin,axis_dots[it],&axis_count[it],&key_v);
					if(!(key_v.X==0&&key_v.Y==0))
						kv_s[ckv++] = key_v;
				}
				if(ckv>2)		//Sonix��Y��������������2�����϶�����
					continue;
				else if(ckv==2)
				{
					if(GetAngle(&kv_s[0],&kv_s[1])<=0)	//����������������һ�£�����
						continue;
				}
				if(ckv)
					key_v = kv_s[0];
	
				axis->type = TYPE_NONE;	//Ĭ��Ϊ��Ч���������ҵ��˿հ���������Ϊ��KB��
				type = TYPE_NONE;
				for(it=0;it<4;++it)
				{
					ax = it;
					ay = (it+1)&3;	//��Ϊ��0��3���±�������cross������90����ת�ģ�����
					//ֻҪ�ҵ��˿հ׵㣬��ôax��ָʾ��X��������cross�е��±꣬ay
					//��ָʾ��Y��������cross�е��±ꣻ
					if(!in_range(&axis_dots[ax][0])||!in_range(&axis_dots[ay][0]))
						continue;
					if(dot_quad(origin,&axis_dots[ax][0],&axis_dots[ay][0],&dot_t))
				//	dot_t.X = axis_dots[ax][0].X + axis_dots[ay][0].X - origin->X;
				//	dot_t.Y = axis_dots[ax][0].Y + axis_dots[ay][0].Y - origin->Y;
				//	if(dot_t.X>=0&&dot_t.X<hi->width&&dot_t.Y>=0&&dot_t.Y<hi->hash_num)
					{
						if(!in_edge(&dot_t)&&!get_close_dot(hi,&dot_t,&result,OFFSET_DATA_DOT))	//�ҿհ׵㣬�ҵ�һ���հ׾�ȷ��ΪKB��
						{
							type = TYPE_KB;
							break;
						}
					}
				}
				if(type == TYPE_KB)
				{
					//������пհ׵������»���Sonix��Y���
					//����Ϊ�ж�����
					for(it = 0;it<4;++it)
					{
						if(axis_type[it] == AXIS_Y||axis_type[it] == AXIS_ERR)
							break;
					}
					if(it!= 4)
						continue;
					//X,Y������Ҫ��һ������Ч��
					if((axis_type[ax]==AXIS_X||axis_type[(ax+2)&3]==AXIS_X)&&
						(axis_type[ay]==AXIS_X||axis_type[(ay+2)&3]==AXIS_X))
						axis->type = TYPE_KB;
					else
						continue;
				}
				else	//�������KB�ı��룬���ж��Ƿ�ΪSonix�룬��Ҫ��X,Y�������ж������ⰲ��
				{
					//����㹹�ɵ����߽����жϣ�������������ΪX�����ᣬ����������ΪY������
					//��cross[]�ĸ����ܵ��±�λ��(ax,ay)
					ax=-1;	ay=-1;
					for(it=0;it<4;++it)
					{
						if(axis_type[it]==AXIS_X)
							ax = it;
						else if(axis_type[it] == AXIS_Y)
							ay = it;
						else if(axis_type[it] == AXIS_ERR)
						{
							ax = ay = -1;
							break;
						}
					}
					if(ax==-1||ay==-1)	//û���ҵ�X��Y�ᣬ����
						continue;
					if(axis_type[(ax+2)&3]==AXIS_Y)	//X,Y��ĸ��᷽�����
						continue;
					if(axis_type[(ay+2)&3]==AXIS_X)
						continue;
					if(ax == ((ay+2)&3))	//X,Y����ͬһ���ϣ�����
						continue;
					if(ay == ((ax+2)&3))
						continue;

					//�û�õ���������key_v������X���������н����ж�
					//��ͬһ����ľ���X��������
					if(GetAngle(&cross[ax],&key_v)>0)
						;
					else if(GetAngle(&cross[(ax+2)&3],&key_v)>0)
						ax = ((ax+2)&3);
					else
						continue;
					ay = (ax+1)&3;
					axis->type = TYPE_SONIX;
				}

				//ͳ��X,Y����������Ƿ�ȫ(����>=3)
				if(axis_count[ax]+axis_count[(ax+2)&3]<MAX_AXIS_DOTS_NUM||
					axis_count[ay]+axis_count[(ay+2)&3]<MAX_AXIS_DOTS_NUM)
					continue;

				//�������������
				axis->origin = *origin;
				for(it=0;it<3;++it)
				{
					axis->axis_dots_x[0][it] = axis_dots[ax][it];
					axis->axis_dots_y[0][it] = axis_dots[ay][it];
				}
				ax = ((ax+2)&3);
				ay = ((ay+2)&3);
				for(it=0;it<3;++it)
				{
					axis->axis_dots_x[1][2-it] = axis_dots[ax][it];
					axis->axis_dots_y[1][2-it] = axis_dots[ay][it];
				}

				//�������õ�һ�����׼ȷ������������ԭ����Զ���Ǹ�����
				for(it=0;it<3;++it)
				{
					if(axis->axis_dots_x[0][2-it].X||axis->axis_dots_x[0][2-it].Y)
					{
						axis->axis_x = vec_get(&axis->origin,&axis->axis_dots_x[0][2-it]);
						break;
					}
					else if(axis->axis_dots_x[1][it].X||axis->axis_dots_x[1][it].Y)
					{
						axis->axis_x = vec_get(&axis->axis_dots_x[1][it],&axis->origin);
						break;
					}
				}
				for(it=0;it<3;++it)
				{
					if(axis->axis_dots_y[0][2-it].X||axis->axis_dots_y[0][2-it].Y)
					{
						axis->axis_y = vec_get(&axis->origin,&axis->axis_dots_y[0][2-it]);
						break;
					}
					else if(axis->axis_dots_y[1][it].X||axis->axis_dots_y[1][it].Y)
					{
						axis->axis_y = vec_get(&axis->axis_dots_y[1][it],&axis->origin);
						break;
					}
				}
				return	TRUE;
			}
		}
	}
	return	FALSE;
}

#if 0
U16 SqrtTbl[50] =	
{
	0,  0,  1,  2,  4,  6,  9,  12, 16, 20,
	25, 30, 36, 42, 49, 56, 64, 72, 81, 90,
	100,110,121,132,144,156,169,182,196,210,
	225,240,256,272,289,306,324,342,361,380,
	400,420,441,462,484,506,529,552,576,600
};

U16 Sqrt(U16 a)
{
	U8 i;
	for (i=0; i<50; i++)
	{
		if (a<=SqrtTbl[i])
			break;
	}
	return i;
}
#endif

const unsigned short g_sq[256] = 
{
	0
	,1
	,4
	,9
	,16
	,25
	,36
	,49
	,64
	,81
	,100
	,121
	,144
	,169
	,196
	,225
	,256
	,289
	,324
	,361
	,400
	,441
	,484
	,529
	,576
	,625
	,676
	,729
	,784
	,841
	,900
	,961
	,1024
	,1089
	,1156
	,1225
	,1296
	,1369
	,1444
	,1521
	,1600
	,1681
	,1764
	,1849
	,1936
	,2025
	,2116
	,2209
	,2304
	,2401
	,2500
	,2601
	,2704
	,2809
	,2916
	,3025
	,3136
	,3249
	,3364
	,3481
	,3600
	,3721
	,3844
	,3969
	,4096
	,4225
	,4356
	,4489
	,4624
	,4761
	,4900
	,5041
	,5184
	,5329
	,5476
	,5625
	,5776
	,5929
	,6084
	,6241
	,6400
	,6561
	,6724
	,6889
	,7056
	,7225
	,7396
	,7569
	,7744
	,7921
	,8100
	,8281
	,8464
	,8649
	,8836
	,9025
	,9216
	,9409
	,9604
	,9801
	,10000
	,10201
	,10404
	,10609
	,10816
	,11025
	,11236
	,11449
	,11664
	,11881
	,12100
	,12321
	,12544
	,12769
	,12996
	,13225
	,13456
	,13689
	,13924
	,14161
	,14400
	,14641
	,14884
	,15129
	,15376
	,15625
	,15876
	,16129
	,16384
	,16641
	,16900
	,17161
	,17424
	,17689
	,17956
	,18225
	,18496
	,18769
	,19044
	,19321
	,19600
	,19881
	,20164
	,20449
	,20736
	,21025
	,21316
	,21609
	,21904
	,22201
	,22500
	,22801
	,23104
	,23409
	,23716
	,24025
	,24336
	,24649
	,24964
	,25281
	,25600
	,25921
	,26244
	,26569
	,26896
	,27225
	,27556
	,27889
	,28224
	,28561
	,28900
	,29241
	,29584
	,29929
	,30276
	,30625
	,30976
	,31329
	,31684
	,32041
	,32400
	,32761
	,33124
	,33489
	,33856
	,34225
	,34596
	,34969
	,35344
	,35721
	,36100
	,36481
	,36864
	,37249
	,37636
	,38025
	,38416
	,38809
	,39204
	,39601
	,40000
	,40401
	,40804
	,41209
	,41616
	,42025
	,42436
	,42849
	,43264
	,43681
	,44100
	,44521
	,44944
	,45369
	,45796
	,46225
	,46656
	,47089
	,47524
	,47961
	,48400
	,48841
	,49284
	,49729
	,50176
	,50625
	,51076
	,51529
	,51984
	,52441
	,52900
	,53361
	,53824
	,54289
	,54756
	,55225
	,55696
	,56169
	,56644
	,57121
	,57600
	,58081
	,58564
	,59049
	,59536
	,60025
	,60516
	,61009
	,61504
	,62001
	,62500
	,63001
	,63504
	,64009
	,64516
	,65025
};


U16	Sqrt(U16 v)
{
	U16	l,r,m;
	l=0;
	r=numof(g_sq);
	while(l<r)
	{
		m = (l+r)/2;
		if(g_sq[m]==v)
			return	m;
		if(g_sq[m]>v)
		{
			r = m;
		}
		else
		{
			l = m+1;
		}
	}
	if(v<g_sq[l])
		--l;
	return	l;
}


S16 GetAngle (VECTOR* pvec1,VECTOR* pvec2)
{
	S16 Len1, Len2;
	S16 Product;
	
	S16 a1=pvec1->X;
	S16 a2=pvec1->Y;
	S16 a3=pvec2->X;
	S16 a4=pvec2->Y;

	Len1 = Sqrt(pvec1->X*pvec1->X+pvec1->Y*pvec1->Y);
	if(Len1 == 0)
		Len1 = 1;
	Len2 = Sqrt(pvec2->X*pvec2->X+pvec2->Y*pvec2->Y);
	if(Len2 == 0)
		Len2 = 1;

	Product = pvec1->X*pvec2->X+pvec1->Y*pvec2->Y;

	//return Product*4000L/(Len1*Len2);
	//return Product*4096L/(Len1*Len2);
	//return	Product*4096/(Len1*Len2);
	return	Product*1024L/(Len1*Len2);
}


U8 get_dot_value_Sonix(VECTOR *pvec,VECTOR *p_axis_x,VECTOR *p_axis_y)
{
	S16 anglex;
	S16 angley;

	if(pvec->X==0&&pvec->Y==0)
		return	0xFF;
	anglex=GetAngle(p_axis_x, pvec);
	angley=GetAngle(p_axis_y,pvec);
	if(anglex==0||angley==0)
		return	0xFF;
	if(anglex>0&&angley>0)
		return	0x0;
	if(anglex<0&&angley>0)
		return	0x1;
	if(anglex<0&&angley<0)
		return	0x2;
	if(anglex>0&&angley<0)
		return	0x3;
	return 0xFF;
}


U8 get_dot_value_KB(VECTOR *pvec,VECTOR *p_axis_x,VECTOR *p_axis_y)
{
	S16 anglex;
	S16 angley;
	U8 ret=0;

	if(pvec->X==0&&pvec->Y==0)
		return	0xFF;
	anglex=GetAngle(p_axis_x, pvec);
	angley=GetAngle(p_axis_y,pvec);
	if(anglex==0||angley==0)
		return	0xFF;
	if(anglex>0)
		ret+=0x02;
	if(angley>0)
		ret+=0x01;
	return ret;
}


U8	check_odd(U16 num)	//��żУ��
{
	U16 mask = 0x8000;
	U8 odd = 0;
	while(mask)
	{
		if(num&mask)
			++odd;
		mask>>=1;
	}
	return (odd&1);
}


U8 get_dot_value_odd(U8 odd,VECTOR *pvec,VECTOR *p_axis_x,VECTOR *p_axis_y)
{
	S16 anglex;
	S16 angley;

	if(pvec->X==0&&pvec->Y==0)
		return	0xFF;
	anglex=GetAngle(p_axis_x, pvec);
	angley=GetAngle(p_axis_y,pvec);
	if(anglex==0||angley==0)
		return	0xFF;
	if(odd)
	{
		if(anglex>0&&angley>0)
			return	3;
		if(anglex<0&&angley>0)
			return	1;
		if(anglex<0&&angley<0)
			return	2;
		if(anglex>0&&angley<0)
			return	0;
	}
	else
	{
		if(anglex>0&&angley>0)
			return	1;
		if(anglex<0&&angley>0)
			return	3;
		if(anglex<0&&angley<0)
			return	0;
		if(anglex>0&&angley<0)
			return	2;
	}
	return 0xFF;
}


const DOT val_dots_Sonix[]=
{
	{1,0}
	,{2,0}
	,{0,1}
	,{1,1}
	,{2,1}
	,{0,2}
	,{1,2}
	,{2,2}
	
	,{0,0}
};


const DOT val_dots_KB[]=
{
	{2,0}
	,{0,1}
	,{1,1}
	,{2,1}
	,{0,2}
	,{1,2}
	,{2,2}

	,{1,0}	// (1,0)����ط��ĵ�����żУ���ã���Ҫ������⴦��
};

#if 0
U16	get_correct(U16 v1,U16 v2, U16 v3)
{
	if(v1==v2)
		return	v1;
	else if(v1 == v3)
		return	v1;
	else	if(v2==v3)
		return	v2;
	return	0;
}
#endif

U16 CoverToCheckNum(U16 index)
{
  U16 sr = index;
  const U16 tsl[8][4] = {{0,1,0,1},{2,3,2,3},{1,0,1,0},{3,2,3,2},{0,2,0,2},{1,3,1,3},{2,0,2,0},{3,1,3,1}};
  const U16 bjdm0[] = {4,5,4,5,6,7,6,7,4,5,4,5,6,7,6,7};
  const U16 bjdm1[] = {5,4,5,4,7,6,7,6,5,4,5,4,7,6,7,6};
  U16 start = (U16)-1;
  U16 cs[5];
  cs[0] = sr/256;
  sr%=256;
  cs[1] = sr/64;
  sr%=64;
  cs[2] = sr/16;
  sr%=16;
  cs[3] = sr/4;
  sr%=4;
  cs[4] = sr;
  if((cs[0]/64)%2==0)//ż
  {
    if((cs[0]/16)%2==0)//ż
    {
      start = bjdm0[cs[0]%16];
    }
    else if((cs[0]/16)%2==1)//��
    {
      start = bjdm1[cs[0]%16];
    }
  }
  else if((cs[0]/64)%2==1)//��
  {
    if((cs[0]/16)%2==0)//ż
    {
      start = bjdm1[cs[0]%16];
    }
    else if((cs[0]/16)%2==1)//��
    {
      start = bjdm0[cs[0]%16];
    }
  }
  start = tsl[start][cs[1]];
  start = tsl[start][cs[2]];
  start = tsl[start][cs[3]];
  start = tsl[start][cs[4]];
  return start;
}


Bool	check_correct(U8 * v,U8 num)
{
	U8 iter;
	if(num<=1)
		return	TRUE;
	for(iter=0;iter<num-1;++iter)
		if(v[iter]!=v[iter+1])
			return	FALSE;
	return	TRUE;
}


U32	calc_num(HashInfo * hi,AXIS* axis,U8* c_code)
{
	DOT	dot_new;
	DOT	dot_t;
	VECTOR	vd;
	S16	iter;
	S16	px,py;
	S16	ix,iy;
	U16	sum=0;
	U16	value;
	U8	v[4];
	U8   cv;
	U8 odd = 0;	//��żУ��
	U8 count =0;
	U8 suc = TRUE;
	if(axis->type == TYPE_SONIX)
	{
		for(iter=0;iter<numof(val_dots_Sonix);++iter)
		{
			px = val_dots_Sonix[iter].X;
			py = val_dots_Sonix[iter].Y;
			cv = 0;
			//ix��iy��ʾx,y�������������㣬
			//0��ʾ������1��ʾ������
			for(iy=0;iy<2;++iy)
			{
				for(ix=0;ix<2;++ix)
				{
					//�˴����ȱʧ������
					if((axis->axis_dots_x[ix][px].X==0&&axis->axis_dots_x[ix][px].Y==0)||
						(axis->axis_dots_y[iy][py].X==0&&axis->axis_dots_y[iy][py].Y==0))
						continue;
					//�����ԭ��������������ݵ��λ��
					//dot_new.X = axis->axis_dots_x[ix][px].X+axis->axis_dots_y[iy][py].X - axis->origin.X;
					//dot_new.Y = axis->axis_dots_x[ix][px].Y+axis->axis_dots_y[iy][py].Y - axis->origin.Y;
					if(!dot_quad(&axis->origin,&axis->axis_dots_x[ix][px],&axis->axis_dots_y[iy][py],&dot_new))
						continue;
					if(get_close_dot(hi,&dot_new,&dot_t,OFFSET_DATA_DOT)!=1)
						continue;
					vd = vec_get(&dot_new,&dot_t);
					value = get_dot_value_Sonix(&vd,&axis->axis_x,&axis->axis_y);
					if(value!= 0xFF)
						v[cv++] = value;
				}
			}
			//һ�����ݵ���������������������ĸ�ֵ������ѡȡ��ȷ��ֵ

			value = 0xFF;
			if(cv>=2)
			{
				if(!check_correct(v,cv))
					suc = FALSE;
				else
					value = v[0];
			}
			else if(cv == 1)
				value = v[0];
			else
				suc = FALSE;
			if(iter==numof(val_dots_Sonix)-1) 
			{
			//	if(c_code)
			//		*c_code = value;
				g_old_value=sum;
			g_old_check=CoverToCheckNum(sum);
		//	g_old_check+=1;
		//	g_old_check%=4;
			
				if(suc)
				{
					if(value==0xFF)
						{
						return	INVALID_NUM;
						}
					if(value != g_old_check)//&&value!=(g_old_check+2)%4)
						{
						return	INVALID_NUM;
						
						}
				}
				/*#if SONIX_CODE_TYPE==SONIX_CODE_FUZHOU
					start=(start+2)%4;
					#endif
				*/
				c_code[iter] = value;
			}
			else
			{
				if(suc)
				{
					sum<<=2;
					sum+=value;
				}
				c_code[iter] = value;
			}
		}
#if 0
		if(suc)
			sum = search_code_table(sum);
#endif
	}
	else if(axis->type == TYPE_KB)
	{
		for(iter=0;iter<numof(val_dots_KB);++iter)
		{
			px = val_dots_KB[iter].X;
			py = val_dots_KB[iter].Y;
			if(iter == 6)
			{
				cv = 1;
			}
			cv = 0;
			//ix��iy��ʾx,y�������������㣬
			//0��ʾ������1��ʾ������
			if(iter==numof(val_dots_KB)-1)
				odd = check_odd(sum);
			for(iy=0;iy<2;++iy)
			{
				for(ix=0;ix<2;++ix)
				{
					//�˴����ȱʧ������
					if((axis->axis_dots_x[ix][px].X==0&&axis->axis_dots_x[ix][px].Y==0)||
						(axis->axis_dots_y[iy][py].X==0&&axis->axis_dots_y[iy][py].Y==0))
						continue;
					//�����ԭ��������������ݵ��λ��
					//dot_new.X = axis->axis_dots_x[ix][px].X+axis->axis_dots_y[iy][py].X - axis->origin.X;
					//dot_new.Y = axis->axis_dots_x[ix][px].Y+axis->axis_dots_y[iy][py].Y - axis->origin.Y;
					if(!dot_quad(&axis->origin,&axis->axis_dots_x[ix][px],&axis->axis_dots_y[iy][py],&dot_new))
						continue;
					if(get_close_dot(hi,&dot_new,&dot_t,OFFSET_DATA_DOT)!=1)
						continue;
					vd = vec_get(&dot_new,&dot_t);
					if(iter<numof(val_dots_KB)-1)
						value = get_dot_value_KB(&vd,&axis->axis_x,&axis->axis_y);
					else
						value = get_dot_value_odd(odd,&vd,&axis->axis_x,&axis->axis_y);
					if(value!=0xFF)
						v[cv++] =value;
				}
			}
			//һ�����ݵ���������������������ĸ�ֵ������ѡȡ��ȷ��
#if 0
			//һ�����ݵ���������������������ĸ�ֵ������ѡȡ��ȷ��
			if(cv>=3)
				value = get_correct(v[0],v[1],v[2]);
			else if(cv>0)
				value = v[0];
			else
				return	0xFFFF;
#else
			value = 0xFF;
			if(cv>=2)
			{
				if(!check_correct(v,cv))
					suc = FALSE;
				else
					value = v[0];
			}
			else if(cv == 1)
				value = v[0];
			else
				suc = FALSE;
#endif
			if(iter<numof(val_dots_KB)-1)
			{
				if(suc)
				{
					sum<<=2;
					sum+=value;
				}
				c_code[iter+1] = value;
			}
			else
			{
				if(suc)
					sum+=(value<<14);
				c_code[0] = value;
			}
		}
	//	if(c_code)
	//		*c_code = check_odd(sum);
	}
	if(suc)
		return	sum;
	else
		return	INVALID_NUM;
}


U32 decode_num(U8* c_code,U8* error)
{
	U32 result;
	U8 iter;
	Bool	suc = FALSE;
   U8 cur_type = TYPE_NONE;
#if PLAT_FORM_TYPE == PLAT_FORM_PC
	AXIS	axis_temp;
#endif
	g_hash_info.dots_num = g_dots_count;
	g_axis.type = TYPE_NONE;
	*error = Decode_OK;
	if(!build_hash_info(&g_hash_info))
	{
		*error = Decode_Hash_Error;
		return	INVALID_NUM;
	}


	g_shift = 0;
	g_up=g_hash_info.dots_num/2;
	g_down = g_up+1;
	while(g_up>=0||g_down<g_hash_info.dots_num)
	{
		for(iter=0;iter<9;++iter)
			c_code[iter] = 0xFF;
		if(!check_axis(&g_hash_info,&g_axis))
		{
			g_axis.type = TYPE_NONE;
			*error = Decode_Axis_Error;
			continue;
		//	return	INVALID_NUM;
		}
#if 1
		result = calc_num(&g_hash_info,&g_axis,c_code);
#endif
		if(result == INVALID_NUM)
		{
			*error = Decode_Calc_Error;
		}
		else
		{
//#if USE_STAT_CODE == TRUE
//			stat_code_set(result);
//			result = stat_code_get();
//#endif
//			return	result;

#if PLAT_FORM_TYPE == PLAT_FORM_PC
			axis_temp = g_axis;
#endif
			suc = TRUE;
         cur_type = g_axis.type;
#if USE_STAT_CODE == TRUE
			stat_code_set(result);
#else
         break;
#endif
		}
	}

	if(suc)
	{
#if PLAT_FORM_TYPE == PLAT_FORM_PC
		g_axis = axis_temp;
#endif
      *error = Decode_OK;
      g_axis.type = cur_type;
#if USE_STAT_CODE == TRUE
		result = stat_code_get();
#endif
	}
	else
	{
      *error = Decode_Axis_Error;
		result = INVALID_NUM;
	}

	return result;
}


#if( USE_STAT_CODE == TRUE )
//�����ٸ���ͬ����ֵ
__X U32	g_stat_queue[ Stat_Num ];
__X U8	g_que_ptr = 0;
__X StatItem g_stat_num[ Stat_Num ];
__X U8	g_item_count = 0;	//�ܹ��ж��ٸ���ͬ����ֵ
//U8	g_code_count;	//������ֵ���ֵ�Ƶ�ʴ���


#pragma CODE = MBC_STAT_CODE

void stat_code_init( void )
{
	U8 iter;
	g_item_count = 0;
//	g_code_count = 0;
	g_que_ptr = 0;
	for(iter=0;iter<Stat_Num;++iter)
	{
		//g_stat_num[iter].code_num = INVALID_NUM;
		g_stat_num[iter].code_count = 0;

		g_stat_queue[iter] = INVALID_NUM;
	}
}


void	stat_code_set(U32 num)
{
	if(num == INVALID_NUM)
		return;
	g_stat_queue[g_que_ptr] = num;
	g_que_ptr ++;
	if(g_que_ptr == Stat_Num)
		g_que_ptr = 0;
}


U8	stat_code_add(U32 num)
{
	U8	iter;
	U8	result;
	if(num == INVALID_NUM)
	{
		return Stat_Num;
	}
	for(iter=0;iter<g_item_count;++iter)
	{
		if(g_stat_num[iter].code_num==num)
		{
			++g_stat_num[iter].code_count;
//			++g_code_count;
			return	iter;
		}
	}
	if(g_item_count==Stat_Num)
		return	Stat_Num;
	g_stat_num[g_item_count].code_num = (U16)num;
	g_stat_num[g_item_count].code_count = 1;
	result = g_item_count;
	++g_item_count;
//	++g_code_count;
	return	result;
}

U32	stat_code_get(void)
{
	U8 iter;
	U8 mc,mi,mt;
	g_item_count = 0;
	for(iter=0;iter<Stat_Num;++iter)
		(void)stat_code_add(g_stat_queue[iter]);
	if(g_item_count == 0)
		return	INVALID_NUM;
	mi = 0;
	mt = 0;
	mc = 0;
	for(iter=0;iter<g_item_count;++iter)
	{
		if(mc<g_stat_num[iter].code_count)
		{
			mi = iter;
			mt = iter;
			mc = g_stat_num[iter].code_count;
		}
		else if(mc == g_stat_num[iter].code_count)
		{
			mt = iter;
		}
	}
	if(mi!=mt)
		return	INVALID_NUM;
	return	g_stat_num[mi].code_num;
}
#endif   //#if( USE_STAT_CODE == TRUE )


#if 0
U8	g_stat_data[8][4];
U8	g_data_count;
void	stat_data_init()
{
	memset_v((U8 *)g_stat_data,0,sizeof(g_stat_data));
	g_data_count = 0;
}

void	stat_data_add(U8 d[8])
{
	U8 iter;
	for(iter=0;iter<8;++iter)
	{
		if(d[iter]<4)
		{
			g_stat_data[iter][d[iter]]++;
		}
	}
	++g_data_count;
}

U16	stat_data_get()
{
	U8 iter,ii;
	U8 mc,mi,mt;
	U16	sum = 0;
	if(g_data_count == 0)
		return	INVALID_NUM;
	for(iter=0;iter<8;++iter)
	{
		mc = 0;
		mi = mt = 0;
		for(ii=0;ii<4;++ii)
		{
			if(mc<g_stat_data[iter][ii])
			{
				mc = g_stat_data[iter][ii];
				mi = mt = ii;
			}
			else if(mc == g_stat_data[iter][ii])
				mt = ii;
		}
		if(mi!=mt)
			return	INVALID_NUM;
		sum<<=2;
		sum+=mi;
	}
	return	sum;
}
#endif
