
#include <KBDM9_DDK.h>
#include <SFR.h>
#include <string.h>
#include "668.h"
#include "cis.h"
#include "Calibration.h"
#include "IRControl.h"


#pragma CODE=Test_Code
#pragma DATA=Test_Data

unsigned int *Calib_Buf;
extern unsigned int ReserveCalibrationData[256], ReserveOk;
unsigned int IR_L, IR_R;
extern unsigned long __X DataAddress, DataLength;

/*
void IR_Init(void)
{
   IR_L=IR_Min;
   IR_R=IR_Min;
   __asm
   {
;  	bset TM1ICR.0  //Enable timer1 ISR
      bset PBEN.8    //PWM4
      bset PBEN.9    //PWM5
   }

   PWM4 = 0;
   PWM5 = 0;
   TM1PRD = IR_Max_Cycle;
   //  SetVector(0x12,IR_ISR);  //Temer1 interrupt rountine
   //TMR1CR=0XD660;           // Enable PWM7,PWM6,CLOCK=12MHZ
   TMR1CR = 0xD018;           // Enable PWM4,PWM5,CLOCK=12MHZ
}
*/

unsigned int Calib_IR(void)
{
   GetDataIdInfo( 128, &DataAddress, &DataLength );
	if( Calib_Right_IR() && Calib_Left_IR())
	{
		ReserveCalibrationData[4] = ReserveCalibrationData[0]+0x10;
		ReserveCalibrationData[5] = IR_Min;
//		ReserveCalibrationData[4] = ReserveCalibrationData[0]-0x0A;
//		ReserveCalibrationData[5] = ReserveCalibrationData[3]-0x0A;

		ReserveCalibrationData[6] = IR_Min;
		ReserveCalibrationData[7] = ReserveCalibrationData[3]+0x10;
//		ReserveCalibrationData[6] = ReserveCalibrationData[0]-0x06;
//		ReserveCalibrationData[7] = ReserveCalibrationData[3]-0x06;

		ReserveCalibrationData[8] = ReserveCalibrationData[4]+0x10;
		ReserveCalibrationData[9] = IR_Min;
		ReserveCalibrationData[10]= IR_Min;
		ReserveCalibrationData[11]= ReserveCalibrationData[7]+0x10;

		ReserveCalibrationData[12]= ReserveCalibrationData[0]-0x06;
		ReserveCalibrationData[13]= ReserveCalibrationData[3]-0x06;
		spif_resv_write( DataAddress, ReserveCalibrationData );
		ReserveOk = 1;
		return 1;
	}
	ReserveOk = 0;
	return 0;
}

unsigned int Calib_Right_IR(void)
{
	int i,j/*,ADCData,ADCCONTemp*/,k;
//        int ADCValue[300];
   unsigned int *p;

   unsigned long ADCAverage,ADCAverage_V;
	//
//	LeftIR_Level(IR_Min);
//	RightIR_Level(IR_Max);
//	//Delayms(30);
//	calibflag=calib_Init;
//
//	while(1)
//	{
//	   if((calibflag==calib_IR_Pass)||(calibflag==calib_IR_Fail))
//		{
//		  break;
//		}
//		  count=0;
//		  Calib_Pt=Calib_Buf;
//		  csflag=CIS_Read_Flag();
//	    if(csflag==0)                 //check new frame
//		  {
//
//		    while(1)
//		    {
//		 	csflag=CIS_Read_Flag();
//		        if (csflag == 1)
//		          {
//		            line_count = CIS_Line_Count();	//read line count
//		            if(count!=line_count)
//		            {
//		               calibflag=calib_IR_Fail;
//		               break;
//		            }
//		             count++;
//		             CIS_Read_CisData(Calib_Pt);
//		             //CIS_Read_CisCalibrationData(Calib_Pt,0,120); //18
//			           Calib_Pt+=60;
//
//			           if(line_count==119)
//			            {
//			                  calibflag=calib_IR_Pass;
//			                  for(i=Calib_WindowsSize*Calib_WindowsSize+10;i<Calib_WindowsSize*Calib_WindowsSize+50;i++)
//			                  {
//			                    if(((Calib_Buf[i]&0xFF00)<0x4000)||((Calib_Buf[i]&0X00FF)<0x0040))
//			                       {
//			                        calibflag=calib_IR_Fail;
//			                        break;
//			                       }
//			                  }
//
//			                   break;
//
//			            }
//	            }
//		     }
//		  }
//	}
//	if(calibflag==calib_IR_Fail)
//	     return  0;
	LeftIR_Level(IR_Min);
	RightIR_Level(IR_Max);
	cs_frame_go();
	while( cis_line_go != 2 );
#if( CIS_X_CNT == 120 )
	for( i= 120 * 60 + 20; i < 120 * 60 + 100; i++ )
      if( cis_line_tmp3[ i ] < 0x40 )
         return 0;
/*#elif( CIS_X_CNT == 240 )
   p = ( unsigned int *)( IRAM_ADDRESS + CIS_X_CNT*10 );
   p += 20;
   for( i = 0; i < 80; i++ )
   {
      if(( *p & 0x00FF )< 0x0040 )
         return 0;
      p++;
   }
#elif( CIS_X_CNT == 200 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*28 ];
   p += 20;
   for( i = 0; i < 60; i++ )
   {
      if(( *p & 0x00FF )< 0x0040 )
      {
         ReserveOk = 2;
         return 0;
      }
      p++;
   }
#elif( CIS_X_CNT == 190 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*21 ];
   p += 20;
   for( i = 0; i < 55; i++ )
   {
      if(( *p & 0x00FF )< 0x0040 )
         return 0;
      p++;
   }
#elif( CIS_X_CNT == 180 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*10 ];
   p += 15;
   for( i = 0; i < 60; i++ )
   {
      if(( *p & 0x00FF )< 0x0040 )
         return 0;
      p++;
   }
#elif( CIS_X_CNT == 170 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT ];
   p += 15;
   for( i = 0; i < 55; i++ )
   {
      if(( *p & 0x00FF )< 0x0040 )
         return 0;
      p++;
   }*/
#endif

//	//
//	LeftIR_Level(IR_Min);
//	RightIR_Level(IR_Max);
//	//Delayms(30);

//	IR_R=IR_Max;
//	calibflag=calib_Init;

//	j=0;
//	ADCAverage_V=0;
//	while(1)
//	{
//		if(calibflag==calib_IR_Pass)
//		{
//		 if(j>=Calib_Num)
//		   break;
//		 else
//		 {
//		   ADCAverage_V+=IR_R;
//		   IR_R=IR_Max;
//		   RightIR_Level(IR_Max);
//		   calibflag=calib_Init;
//		 }
//
//		 j++;
//		}
//		if(calibflag==calib_IR_Fail)
//		{
//			break;
//		}

//		count=0;
//		Calib_Pt=Calib_Buf;
//		csflag=CIS_Read_Flag();
//		if(csflag==0)                 //check new frame
//		 {
//		    while(1)
//		    {
//		 	csflag=CIS_Read_Flag();
//		        if (csflag == 1)
//		          {
//		            line_count = CIS_Line_Count();	//read line count
//		            if(count!=line_count)
//		            {
//		               calibflag=calib_IR_Fail;
//		               break;
//		            }
//		             count++;
//		             CIS_Read_CisData(Calib_Pt);
//		             //CIS_Read_CisCalibrationData(Calib_Pt,0,120); //18
//			           Calib_Pt+=60;
//
//			           if(line_count==119)
//			            {

//			                  for(i=0;i<Calib_WindowsSize*Calib_WindowsSize*2;i++)
//			                  {
//			                    if(((Calib_Buf[i]&0xFF00)>0xF500)||((Calib_Buf[i]&0X00FF)>0x00F5))
//			                       {
//			                            calibflag=calib_IR_Running;
//			                       }
//			                   }
//
//			                   if(calibflag==calib_IR_Running)
//			                   {
//			                      IR_R--;
//			                      IR_R--;
//			                      if(IR_R<(IR_Min+10))
//			                            calibflag=calib_IR_Fail;
//			                      else
//			                        {
//		                             RightIR_Level(IR_R);
//		                             calibflag=calib_Init;
//		                            // Delayms(10);
//		                           }
//			                  }
//			   	           else
//			                   {
//			                      calibflag=calib_IR_Pass;
//			                     // ReserveCalibrationData[0]=IR_R;
//			                     // ReserveCalibrationData[1]=IR_Min;
//			                    }
//			                    break;
//			            }
//	            }
//		    }
//     }
//	}

	for( IR_R = IR_Max, ADCAverage_V = 0,j = 0; j < Calib_Num; j++ )
	{
calib_right_next:
      cs_frame_go();
      while( cis_line_go != 2 );
#if 1//( CIS_X_CNT == 120 )
      for( i = 0; i < 120 * 120; i++ )
      {
        if( cis_line_tmp3[i] > 0xF5 )
         {
            j--;
            IR_R -= 2;
            if( IR_R <( IR_Min + 10 ))
               //j = Calib_Num;
               return 0;
            else
               RightIR_Level( IR_R );
            break;
         }
      }
      if( i >= 120 * 120 )
      {
         ADCAverage_V += IR_R;
         RightIR_Level( IR_R = IR_Max );
     }
#else
		//p = ( unsigned int *)&cis_line_buffer;
		//for( k = 0; k < X_RAM_LINE; k++ )
		for( k = 0; k < X_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)&cis_line_buffer[ CIS_X_CNT*k ];
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
      					//goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
      					//goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }*/
            p++;
         }
		}

      //p = ( unsigned int *)&cis_line_buffer1;
      //for( k = 0; k < Y_RAM_LINE; k++ )
		for( k = 0; k < Y_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*k ];
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
                     //goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
      					//goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }*/
            p++;
         }
		}

      //p = ( unsigned int *)IRAM_ADDRESS;
      //for( k = 0; k < I_RAM_LINE; k++ )
		for( k = 0; k < I_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)( IRAM_ADDRESS + CIS_X_CNT*k );
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
      					//goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_R -= 2;
      				if( IR_R < ( IR_Min + 10 ))
      				{
      					//goto calib_right_exit;
      					return 0;
      				}
      				else
      					RightIR_Level( IR_R );
      				goto calib_right_next;
               }
            }*/
            p++;
         }
		}

      ADCAverage_V += IR_R;
      RightIR_Level( IR_R = IR_Max );
#endif
	}

calib_right_exit:

// 	if(calibflag==calib_IR_Pass)
//	{
//            ReserveCalibrationData[0]=(unsigned int)ADCAverage_V/Calib_Num;
//	    ReserveCalibrationData[1]=IR_Min;
//
//           LeftIR_Level(0X00);
//	   RightIR_Level(IR_Max_Cycle);
//	   Delayms(5);
//
//           ADCCONTemp=ADCCON;
//           ADCCON=0X8028;               //  ADC CH5 enable, 3MHZ
//	   ADCAverage=0;
//		 for(i=0;i<300;i++)
//	    {
//          __asm{
//	           BSET ADCCON.0   //Kick off data transfer
//
//	         }
//	     while(1)
//	     {
//	     	if((ADCCON&0x01)==0)
//	     	 {
//	     	 	__asm
//	     	 	{
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 	}
//	     	 	break;
//	     	 }
//	     }
//	    ADCData=ADCD>>6;
//	    ADCValue[i]=ADCData&0xFFF;
//	    ADCAverage+=ADCValue[i];
//	   }
//
//	   ADCAverage=ADCAverage/300;
//	   ADCCON=ADCCONTemp;
//	   ReserveCalibrationData[14]=(unsigned int)ADCAverage;
//	   RightIR_Level(0x00);
//           LeftIR_Level(0x00);
//	    return 1;
//	}
//	else
//	    return 0;

	ReserveCalibrationData[0] = (unsigned int)ADCAverage_V/Calib_Num;
	ReserveCalibrationData[1] = IR_Min;
	return 1;
}


unsigned int Calib_Left_IR(void)
{
   int i,j/*,ADCData,ADCCONTemp*/,k;
//  int ADCValue[300];
   unsigned int *p;

  unsigned long ADCAverage,ADCAverage_V;

  //
//	LeftIR_Level(IR_Max);
//	RightIR_Level(IR_Min);
//	//Delayms(30);
//	calibflag=calib_Init;
//
//	while(1)
//	{
//	   if((calibflag==calib_IR_Pass)||(calibflag==calib_IR_Fail))
//		{
//		  break;
//		}
//	    count=0;
//		  Calib_Pt=Calib_Buf;
//		  csflag=CIS_Read_Flag();
//	    if(csflag==0)                 //check new frame
//		  {
//		    while(1)
//		    {
//		 	      csflag=CIS_Read_Flag();
//		        if (csflag == 1)
//		          {
//		            line_count = CIS_Line_Count();	//read line count
//		            if(count!=line_count)
//		            {
//		               calibflag=calib_IR_Fail;
//		               break;
//		            }
//		             count++;
//		             CIS_Read_CisData(Calib_Pt);
//		             //CIS_Read_CisCalibrationData(Calib_Pt,0,120); //18
//			           Calib_Pt+=60;
//
//			           if(line_count==119)
//			            {
//			                  calibflag=calib_IR_Pass;
//			                  for(i=Calib_WindowsSize*Calib_WindowsSize+10;i<Calib_WindowsSize*Calib_WindowsSize+50;i++)
//			                  {
//			                    if(((Calib_Buf[i]&0xFF00)<0x4000)||((Calib_Buf[i]&0X00FF)<0x0040))
//			                       {
//			                        calibflag=calib_IR_Fail;
//			                        break;
//			                       }
//			                  }
//
//			                   break;
//
//			            }
//	            }
//		     }
//		  }
//	}
//	if(calibflag==calib_IR_Fail)
//	     return  0;
	LeftIR_Level(IR_Max);
	RightIR_Level(IR_Min);
	cs_frame_go();
	while( cis_line_go != 2 );
#if( CIS_X_CNT == 120 )
   for( i = 120 * 60 + 20; i < 120 * 60 + 100; i++ )
      if( cis_line_tmp3[ i ] < 0x40 )
         return 0;
/*#elif( CIS_X_CNT == 240 )
   p = ( unsigned int *)( IRAM_ADDRESS + CIS_X_CNT*10 );
   for( i = 20; i < 100; i++ )
   {
      if(( p[ i ] & 0x00FF )< 0x40 )
         return 0;
   }
#elif( CIS_X_CNT == 200 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*28 ];
   for( i = 20; i < 80; i++ )
   {
      if(( p[ i ] & 0x00FF )< 0x40 )
         return 0;
   }
#elif( CIS_X_CNT == 190 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*21 ];
   for( i = 20; i < 75; i++ )
   {
      if(( p[ i ] & 0x00FF )< 0x40 )
         return 0;
   }
#elif( CIS_X_CNT == 180 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*10 ];
   for( i = 15; i < 75; i++ )
   {
      if(( p[ i ] & 0x00FF )< 0x40 )
         return 0;
   }
#elif( CIS_X_CNT == 170 )
   p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT ];
   for( i = 15; i < 70; i++ )
   {
      if(( p[ i ] & 0x00FF )< 0x40 )
         return 0;
   }*/
#endif

//  LeftIR_Level(IR_Max);
//  RightIR_Level(IR_Min);
//  //Delayms(50);
//
//        IR_L=IR_Max;
//	calibflag=calib_Init;
//
//	j=0;
//	ADCAverage_V=0;
//
//	while(1)
//	{
//
//		if(calibflag==calib_IR_Pass)
//		{
//		 if(j>=Calib_Num)
//		   break;
//		 else
//		 {
//		   //ADCValue_V[j]=IR_R;
//		   ADCAverage_V+=IR_L;
//		   IR_L=IR_Max;
//		   LeftIR_Level(IR_Max);
//		   calibflag=calib_Init;
//		 }
//
//		 j++;
//		}
//		if(calibflag==calib_IR_Fail)
//		{
//			break;
//		}
//
//		count=0;
//		Calib_Pt=Calib_Buf;
//		csflag=CIS_Read_Flag();
//		if(csflag==0)                 //check new frame
//		 {
//		    while(1)
//		    {
//		 	csflag=CIS_Read_Flag();
//		        if (csflag == 1)
//		          {
//		            line_count = CIS_Line_Count();	//read line count
//		            if(count!=line_count)
//		               break;
//		             count++;
//		             CIS_Read_CisData(Calib_Pt);
//		             //CIS_Read_CisCalibrationData(Calib_Pt,0,120); //18
//			           Calib_Pt+=60;
//
//			           if(line_count==119)
//			            {
//			                  for(i=0;i<Calib_WindowsSize*Calib_WindowsSize*2;i++)
//			                  {
//			                    if(((Calib_Buf[i]&0xFF00)>0xF500)||((Calib_Buf[i]&0X00FF)>0x00F5))
//			                       {
//			                            calibflag=calib_IR_Running;
//			                       }
//			                   }
//
//			                   if(calibflag==calib_IR_Running)
//			                   {
//			                      IR_L--;
//			                      IR_L--;
//			                      if(IR_L<(IR_Min+10))
//			                             calibflag=calib_IR_Fail;
//			                      else
//			                        {
//		                             LeftIR_Level(IR_L);
//		                             calibflag=calib_Init;
//		                             //Delayms(10);
//		                           }
//			                   }
//			   	           else
//			                   {
//
//			                      calibflag=calib_IR_Pass;
//			                     // ReserveCalibrationData[2]=IR_Min;
//			                     // ReserveCalibrationData[3]=IR_L;
//			                    }
//			                    break;
//			            }
//	            }
//		    }
//     }
//	}
	for( IR_L=IR_Max,ADCAverage_V=0,j=0; j<Calib_Num; j++ )
	{
calib_left_next:
		cs_frame_go();
		while( cis_line_go != 2 );
#if 1//( CIS_X_CNT == 120 )
      for( i = 0; i < 120 * 120; i++ )
      {
 		if( cis_line_tmp3[ i ] > 0xF5 )
         {
            j--;
            IR_L -= 2;
            if( IR_L <( IR_Min + 10 ))
               //j = Calib_Num;
               return 0;
            else
               LeftIR_Level( IR_L );
            break;
         }
      }
      if( i >= 120 * 120 )
      {
         ADCAverage_V += IR_L;
         LeftIR_Level( IR_L = IR_Max );
      }
#else
      //p = ( unsigned int *)&cis_line_buffer;
      //for( k = 0; k < X_RAM_LINE; k++ )
		for( k = 0; k < X_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)&cis_line_buffer[ CIS_X_CNT*k ];
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }*/
            p++;
         }
		}

      //p = ( unsigned int *)&cis_line_buffer1;
      //for( k = 0; k < Y_RAM_LINE; k++ )
		for( k = 0; k < Y_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)&cis_line_buffer1[ CIS_X_CNT*k ];
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }*/
            p++;
         }
		}

      //p = ( unsigned int *)IRAM_ADDRESS;
		//for( k = 0; k < I_RAM_LINE; k++ )
      for( k = 0; k < I_RAM_LINE; k += 2 )
		{
         p = ( unsigned int *)( IRAM_ADDRESS + CIS_X_CNT*k);
         for( i = 0; i < CIS_X_CNT/2; i++ )
         {
            //if( !( k & 0x01 ))
            {
               if(( *p & 0x00FF )> 0x00F5 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }
            /*else
            {
               if(( *p & 0xFF00 )> 0xF500 )
               {
                  IR_L -= 2;
      				if( IR_L < ( IR_Min + 10 ))
      					//goto calib_left_exit;
      					return 0;
      				else
      					RightIR_Level( IR_L );
      				goto calib_left_next;
               }
            }*/
            p++;
         }
		}

      ADCAverage_V += IR_L;
      RightIR_Level( IR_L = IR_Max );
#endif
	}
calib_left_exit:
// 	if(calibflag==calib_IR_Pass)
//	{
//           ReserveCalibrationData[3]=(unsigned int)ADCAverage_V/Calib_Num;
//	   ReserveCalibrationData[2]=IR_Min;
//
//
//
//          ADCCONTemp=ADCCON;
//	  ADCCON=0X8020;               //  ADC CH4 enable, 3MHZ
//	  ADCAverage=0;
//	  LeftIR_Level(IR_Max_Cycle);
//	  RightIR_Level(0X00);
//	  Delayms(5);
//		 for(i=0;i<300;i++)
//	    {
//           __asm{
//	           BSET ADCCON.0   //Kick off data transfer
//
//	         }
//	     while(1)
//	     {
//	     	if((ADCCON&0x01)==0)
//	     	 {
//	     	 	__asm
//	     	 	{
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 		nop
//	     	 	}
//	     	 	break;
//	     	 }
//	     }
//	    ADCData=ADCD>>6;
//	    ADCValue[i]=ADCData&0xFFF;
//	    ADCAverage+=ADCValue[i];
//	   }
//	   ADCAverage=ADCAverage/300;
//	   ADCCON=ADCCONTemp;
//	   ReserveCalibrationData[15]=(unsigned int)ADCAverage;
//	   RightIR_Level(0x00);
//           LeftIR_Level(0x00);
//		 return 1;
//	}
//	else
//	     return 0;
	ReserveCalibrationData[3] = (unsigned int)ADCAverage_V/Calib_Num;
	ReserveCalibrationData[2] = IR_Min;
	return 1;
}

/*
void IR_Close(void)
{
	TMR1CR=0X00;        // Disable Timer1

	__asm
        {
  	     bclr TM1ICR.0  //disable timer1 ISR
  	     bclr PBDIR.8
             bclr PBDIR.9
             //bclr PBOD.10
   	     //bclr PBOD.11
   	     bset PBOD.8
   	     bset PBOD.9

        }

}
void LeftIR_Level(unsigned int level)
{
	PWM4= level;
}
void RightIR_Level(unsigned int level)
{
	PWM5= level;
}
*/
void __interrupt IR_ISR(void)
{
	return;
}
