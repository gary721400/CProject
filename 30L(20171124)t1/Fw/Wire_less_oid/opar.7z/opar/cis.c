/*******************************************************************
 * Copyright (c) 2010
 * British Virgin Isiands Billion Gold Securities Ltd.
 * File Name    : cis.c
 * Author       :
 * Create Date  : Oct. 27, 2010
 * History      :
 * Remark       :
*******************************************************************/
#include <ISD12_DDK.H>
#include <fs.h>
#include <string.h>
#include "668.h"
#include "cis.h"
#include "IRControl.h"
#include "SDImg.h"

//--------------------------------------------------------------------
#pragma CODE = CIS_CODE
#pragma DATA = CIS_XRAM
//--------------------------------------------------------------------
__X unsigned int IR_Level[7][2];
__X unsigned int IR_Count;

//--------------------------------------------------------------------
#pragma CODE = CIS_INIT_CODE
//--------------------------------------------------------------------
CIS_ERR CIS_Init(void)
{
	int init_err,err;

	unsigned long SectorAddress,DataLength;
	unsigned int Data[256];

	SetVector(0x1e,i2c_int);
	SetVector(0x28,cs_int);
//	SetVector(0x22,vsync_int);  		//portB
	SetVector(0x24,vsync_int);  		//portC

//	clear_cis_line_buffer();
	init_err = initial_cis_driver();
	if ((init_err == (-1))&&(err == (-1)))
		return -1;
#ifdef CMOS_CIF
	write_cis_reg_byte(0x12,0x00);
	write_cis_reg_byte(0x11,CMOS_NORMAL_CLK);
	write_cis_reg_byte(0x17,0x18);
	write_cis_reg_byte(0x18,0x36);
	write_cis_reg_byte(0x19,0x04);
	write_cis_reg_byte(0x1a,0x22);
	write_cis_reg_byte(3,0x4a);
	write_cis_reg_byte(0x32,0x2d);
	write_cis_reg_byte(0x00, 0x0A);
	write_cis_reg_byte(0x10, 0x1F);
	Delay30ms();
	Delay30ms();
#else
	write_cis_reg_byte(0x12,0x20);
	write_cis_reg_byte(0x11,CMOS_NORMAL_CLK);
	write_cis_reg_byte(0x17,0x14);
	write_cis_reg_byte(0x18,0x23);
	write_cis_reg_byte(0x19,0x02);
	write_cis_reg_byte(0x1a,0x11);
	write_cis_reg_byte(3,0x4a);
	write_cis_reg_byte(0x32,0x24);
	Delay30ms();

	write_cis_reg_byte(0x00, 0x12);
	write_cis_reg_byte(0x10, 0x06);
#endif

	IR_Init();
//	while ( !ADC_Calibration() );

	GetDataIdInfo(D_CAB,&SectorAddress,&DataLength);

#ifdef SDBOOT_ISD12
	sdtl_resv_read(SectorAddress,Data);
#endif

#ifdef SPIBOOT_ISD12
	spif_resv_read(SectorAddress,Data);
#endif

	memcpy(IR_Level, Data, sizeof(IR_Level[0][0])*14);

	IR_Count = 6;

	LeftIR_Level(IR_Level[IR_Count][0]);
	RightIR_Level(IR_Level[IR_Count][1]);

	__asm
	{
		MOV	PCICR, #0x11    ;cis_vsync_icr
		NOP
		bset	pcpie.3		;cis_vsync_pie
		bclr	pcpif.3		;cis_vsync_pif
		nop
	}

	return 0;
}

//--------------------------------------------------------------------
#pragma CODE = CIS_CODE
//--------------------------------------------------------------------
CIS_ERR CIS_Write_Reg(unsigned int RegAddr, unsigned int RegData)
{
	int write_err;
	write_err = write_cis_reg_byte(RegAddr, RegData);
	if (write_err == (-1))
		return -2;
	return 0;
}
//--------------------------------------------------------------------
CIS_ERR CIS_Read_Reg(unsigned int RegAddr)
{
	int read_err;
	read_err = read_cis_reg_byte(RegAddr);
	if (read_err == (-1))
		return -3;
	return read_err;
}
//--------------------------------------------------------------------
CIS_FLAG CIS_Read_Flag(void)
{
	if ((cis_flag ==3))  //&&(cis_y_count==0)
	{
		cis_flag = cis_flag & 0xFFFEU;
		return 0;
	}
	else if (cis_flag==2)
	{
		 cis_flag = cis_flag & 0xFFFDU;
		return 1;
	}
	else
	{
		return -1;
	}
}
//--------------------------------------------------------------------
unsigned int CIS_Line_Count(void)
{
	return cis_y_count;
}
//--------------------------------------------------------------------
void CIS_Read_CisData(__X unsigned int *ptr)
{
	memcpy(ptr, (__X unsigned int*)cis_buffer_point, cis_x_byte);
}
//--------------------------------------------------------------------
void CIS_Read_CisCalibrationData(__X unsigned int *ptr,unsigned StartPoint,unsigned int length)
{
	memcpy(ptr, (__X unsigned int*)(cis_buffer_point+StartPoint),length);
}
//--------------------------------------------------------------------
