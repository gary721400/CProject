#ifndef _Calibration_H
#define _Calibration_H

//#define IR_Max  0X45
#define IR_Min  0X01

#define IR_Max_Cycle 0x4FF


#define Calib_WindowsSize 60  //  120/2
#define Calib_Num 3  //


//#define ADC_0R_Low  0x1F2
#define ADC_0R 0x2B          //0x202  PWM=0X24
#define ADC_2R 0x4F          //0x22D  PWM=0X28
#define ADC_4R 0x6F          //0x251  PWM=0X2E
#define ADC_6R 0x83         //0x271  PWM=0X38
#define ADC_8R 0x96         //0x285  PWM=0X44
#define ADC_10R 0xAA        //0x298  PWM=0X50

/*
#define ADC_0R_Low  0x1F2
#define ADC_0R 0x217         //0x202  PWM=0X24
#define ADC_2R 0x23F         //0x22D  PWM=0X28
#define ADC_4R 0x261         //0x251  PWM=0X2E
#define ADC_6R 0x27B         //0x271  PWM=0X38
#define ADC_8R 0x28E         //0x285  PWM=0X44
#define ADC_10R 0x2B0        //0x298  PWM=0X50
*/
#define ADC_2R_V 0X04
#define ADC_4R_V 0X06
#define ADC_6R_V 0X14
#define ADC_8R_V 0X20
#define ADC_10R_V 0X2C


typedef enum {

	calib_Init =0,
	calib_IR_Running=1,
	calib_IR_Fail=2,
	calib_IR_Pass=3,

}Calibration_FLAG;

//IR Control Function


void IR_Init(void);
void IR_Close(void);
void LeftIR_Level(unsigned int level);
void RightIR_Level(unsigned int level);
unsigned int Calib_IR(void);

unsigned int Calib_Right_IR(void);
unsigned int Calib_Left_IR(void);
void __interrupt IR_ISR(void);
void Delayms(unsigned int ms);
void System_Init(void);

unsigned int ADC_Calibration(void);    //Return 1 pass, Return 0 fail
void Get_Calibration_Data(__X unsigned int*);    //Return 1 pass, Return 0 fail


#endif