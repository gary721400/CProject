
#include "sfr.h"
#include "668.h"

#include <ISD12_DDK.H>
#include "mbc_decode.h"

#pragma DATA = CIS_DATA
#pragma CODE = CIS_CODE

__X   unsigned char  *cis_line_point;
__X   unsigned char  *cis_read_point;

//#define  IRAM_ADDRESS         0x15000

__X   unsigned char     cis_line_go;
__X   unsigned char     cis_line_get, line_num;
__X   unsigned char     cis_line_number;
//__X   unsigned int   cis_line_code;
//__X   unsigned int   cis_line_code_end;

__X   unsigned char     cis_line_count;

__X   unsigned char     cis_line_tmp1[ CIS_X_CNT ];
//__X   unsigned char     cis_line_tmp2[ CIS_X_CNT ];

__X   unsigned char     cis_line_tmp3[ CIS_X_CNT/2*CIS_Y_CNT/2 ];


/*
#define  cis_frame_flag          0        //new flame flag
#define  cis_line_flag           1        //new line flag
#define  cis_line_count          2        //read line count
#define  cis_buffer_point        3        //read line buffer point
#define  cis_frame_count         4        //read frame count
#define  cis_error_flag          0x100    //read cis error flag
*/

#if CMOS_CIF
#define  ini_cis_x_byte          240
#define  ini_cis_y_byte          240
#else
#define  ini_cis_x_byte          120
#define  ini_cis_y_byte          120
#endif

#define  cis_vsync_dir           ( _PCDIR_b0 + 3 )    //PCDIR.3
#define  cis_vsync_en            ( _PCEN_b0 + 3 )     //PCEN.3
#define  cis_vsync_id            ( _PCID_b0 + 3 )     //PCID
#define  cis_vsync_ph            ( _PCPH_b0 + 3 )     //PCPH.3
//#define  cis_vsync               R3.3
#define  cis_vsync_pif           ( _PCPIF_b0 + 3 )    //PCPIF.3
#define  cis_vsync_icr           ( _PCICR_b0 + 0 )    //PCICR.0
#define  cis_vsync_pie           ( _PCPIE_b0 + 3 )    //PCPIE.3

#define  i2c_id                  PCID
#define  i2c_od                  PCOD
//#define  i2c_clk                 R0.1
#define  i2c_clk_en              ( _PCEN_b0 + 1 )     //PCEN.1
#define  i2c_clk_dir             ( _PCDIR_b0 + 1 )    //PCDIR.1
#define  i2c_clk_od              ( _PCOD_b0 + 1 )     //PCOD.1
#define  i2c_clk_ph              ( _PCPH_b0 + 1 )     //PCPH.1
//#define  i2c_sda                 R0.2
#define  i2c_sda_en              ( _PCEN_b0 + 2 )     //PCEN.2
#define  i2c_sda_dir             ( _PCDIR_b0 + 2 )    //PCDIR.2
#define  i2c_sda_od              ( _PCOD_b0 + 2 )     //PCOD.2
#define  i2c_sda_ph              ( _PCPH_b0 + 2 )     //PCPH.2
#define  i2c_sda_id              ( _PCID_b0 + 2 )     //PCID.2

#define  i2c_addr                0x42

#if 0

#define  i2c_re_start()          i2c_start()


void           initial_i2c       ( void );
int            i2c_write_byte    ( unsigned int reg_addr, unsigned int reg_data );
int            i2c_write_byte2   ( unsigned int data );
int            i2c_read_byte     ( unsigned int reg_addr );
unsigned int   i2c_read_byte2    ( void );
void           i2c_start         ( void );
void           i2c_stop          ( void );
void           i2c_clock_delay   ( void );
void           Delay30ms         ( void );

void initial_i2c( void )
{
   _bitCLR( i2c_sda_en );
   _bitCLR( i2c_clk_en );
   _bitSET( i2c_sda_od );
   _bitSET( i2c_clk_od );
   _bitCLR( i2c_sda_dir );
   _bitCLR( i2c_clk_dir );
   _bitSET( i2c_sda_ph );
   _bitSET( i2c_clk_ph );
}


int i2c_write_byte( unsigned int reg_addr, unsigned int reg_data )
{
   int result = -1;
   
   i2c_start();
   if( !i2c_write_byte2( i2c_addr ))
   {
      if( !i2c_write_byte2( reg_addr ))
      {
         result = i2c_write_byte2( reg_data );
      }
   }
   i2c_stop();
   return result;
}


int i2c_write_byte2( unsigned int data )
{
   register unsigned int i = 8;

   do
   {
      if( data & 0x0080 )
      {
         _bitSET( i2c_sda_od );
      }
      else
      {
         _bitCLR( i2c_sda_od );
      }
      data <<= 1;
      i2c_clock_delay();
      _bitSET( i2c_clk_od );
      i2c_clock_delay();
      _bitCLR( i2c_clk_od );
   }
   while( --i );

   _bitSET( i2c_sda_dir );
   i2c_clock_delay();
   _bitSET( i2c_clk_od );
   i = _bit_get( i2c_sda_id );
   i2c_clock_delay();
   _bitCLR( i2c_sda_od );
   _bitCLR( i2c_clk_od );
   _bitCLR( i2c_sda_dir );
   i2c_clock_delay();
   i2c_clock_delay();
   if( i )
      return -1;
   return 0;
}


int i2c_read_byte( unsigned int reg_addr )
{
   int result = -1;
   
   i2c_start();
   if( !i2c_write_byte2( i2c_addr ))
   {
      if( !i2c_write_byte2( reg_addr ))
      {
         i2c_re_start();
         if( !i2c_write_byte2( i2c_addr+1 ))
         {
            result = i2c_read_byte2();
         }
      }
   }
   i2c_stop();
   return result;
}


unsigned int i2c_read_byte2( void )
{
   register unsigned int i = 8, data = 0;
   
   _bitSET( i2c_sda_dir );

   do
   {
      i2c_clock_delay();
      _bitSET( i2c_clk_od );
      data <<= 1;
      if( _bit_get( i2c_sda_id ))
         data |= 0x01;
      i2c_clock_delay();
      _bitCLR( i2c_clk_od );
   }
   while( --i );

   _bitSET( i2c_sda_od );
   _bitCLR( i2c_sda_dir );
   i2c_clock_delay();
   _bitSET( i2c_clk_od );
   i2c_clock_delay();
   _bitCLR( i2c_clk_od );
   _bitCLR( i2c_sda_od );

   return data;
}


void i2c_start( void )
{
   _bitSET( i2c_sda_od );
   i2c_clock_delay();
   _bitSET( i2c_clk_od );
   i2c_clock_delay();
   _bitCLR( i2c_sda_od );
   i2c_clock_delay();
   _bitCLR( i2c_clk_od );
   i2c_clock_delay();
   i2c_clock_delay();
   i2c_clock_delay();
}


void i2c_stop( void )
{
   _bitCLR( i2c_sda_od );
   _bitCLR( i2c_clk_od );
   i2c_clock_delay();
   _bitSET( i2c_clk_od );
   i2c_clock_delay();
   _bitSET( i2c_sda_od );
   i2c_clock_delay();
}


void i2c_clock_delay( void )
{
   register unsigned int i = 150;

   while( --i );
}


//write byte to reg_buffer & CIS
//if ok return = 0 else -1
unsigned int write_cis_reg_byte( unsigned int reg_addr, unsigned int reg_data )
{
   return i2c_write_byte( reg_addr, reg_data );
}


//read CIS to reg_buffer & return
//if ok then return data else -1
unsigned int read_cis_reg_byte( unsigned int reg_addr )
{
   return i2c_read_byte( reg_addr );
}


void __interrupt i2c_int( void )
{
   /*__asm
   {
      BSET I2CCR.4   ;stop bit
   }*/
   _bitSET( _I2CCR_b0 + 4 );  //stop bit
}


int initial_cis_driver( void )
{
   unsigned int i, j;
   
   _bitCLR( _PBDIR_b0 + 0 );
   _bitSET( _PBOD_b0 + 0 );
   Delay30ms();
   _bitCLR( _PBOD_b0 + 0 );

   PBEN |= 0x00FF;

   _bitCLR( cis_vsync_en );
   _bitSET( cis_vsync_dir );
   _bitCLR( cis_vsync_ph );

   initial_i2c();

   PCDIR |= 0x0600;     //PC9       PC10
   PCPH &= ~0x0600u;    //PCLKA     HREF

   Delay30ms();

   i = 0;
   j = 10;
   do
   {
      do
      {
         if( !( _bit_get( cis_vsync_id )))
         {
            goto vsync_low_next;
         }
         __asm
         {
            NOP
         }
      }
      while( ++i );
   }
   while( --j );
   return -1;

vsync_low_next:
   i = 0;
   j = 10;
   do
   {
      do
      {
         if( _bit_get( cis_vsync_id ))
         {
            goto vsync_low_high;
         }
         __asm
         {
            NOP
         }
      }
      while( ++i );
   }
   while( --j );
   return -1;

vsync_low_high:
   i = 2000;
   do
   {
      
      if( !( _bit_get( cis_vsync_id )))
      {
         return -1;
      }
      __asm
      {
         NOP
      }
   }
   while( --i );

   /*__asm
   {
      BCLR CSICR.0   ;disable CMOS interrupt
   }*/
   CSICR = 0x00;
   CSCON = 0x00;
   return 0;
}
#endif

void __interrupt vsync_int( void )
{
   unsigned int i = 0;

   do
   {
      if( _bit_get( cis_vsync_id ))
      {
         goto vsync_int_exit;
      }
      i += 2;
   }
   while( i < 200 );

   _bitCLR( cis_vsync_icr );
   _bitCLR( cis_vsync_pie );
   _bitCLR( cis_vsync_pif );

   //( void )init_raw_data();
   
   //cis_line_get = 0;
   cis_line_count = 0;
   //cis_line_number = 0;
   cis_line_point = cis_line_tmp3;
   cis_read_point = cis_line_tmp3;




   CSWDBA = ( unsigned int )&cis_line_tmp1[ 0 ];    //CSI write DMA buffer address
   CSCON = 0x9400;
   CSICR = 0x31;              //enable CMOS interrupt

vsync_int_exit:
   _bitCLR( cis_vsync_pif );
}



void __interrupt cs_int( void )
{
   register unsigned char i;
   unsigned int *p;

   _bitXOR( _PCOD_b0 + 6, 1 );

   _bitCLR( _CSCON_b0 + 11 );
#if 0
   if( cis_line_count++ >= CIS_Y_CNT )
   {
      CSICR = 0;
      CSCON = 0;

      _bitCLR( cis_vsync_icr );
      _bitCLR( cis_vsync_pie );
      _bitCLR( cis_vsync_pif );

      cis_line_go = 2;
      return;
   }
#endif

   cis_line_count++;

   if( !( cis_line_count & 0x01 ))
   {
      //CSWDBA = ( unsigned int )&cis_line_tmp1[ 0 ]; //CSI write DMA buffer address
      return;
      //p = cis_line_tmp2;
   }
   //else
   {
      //CSWDBA = ( unsigned int )&cis_line_tmp2[ 0 ];    //CSI write DMA buffer address
      p = ( unsigned int *)cis_line_tmp1;
   }

   /*if( cis_line_count == 1 )
   {
      cis_line_go = 1;
   }*/
   
   //p = cis_line_tmp1;
   i = 0;
   do
   {
      *cis_line_point++ = *p++;
   }
   while( ++i < CIS_X_CNT/2 );

   cis_line_get++;
   //line_num++;

#if 1
   if( cis_line_count >= CIS_Y_CNT-1 )
   //if( cis_line_count >= CIS_Y_CNT )
   {
      CSICR = 0;
      CSCON = 0;

      _bitCLR( cis_vsync_icr );
      _bitCLR( cis_vsync_pie );
      _bitCLR( cis_vsync_pif );

      //cis_line_point = cis_line_tmp3;
      cis_line_go = 2;

      return;
   }
#endif



}


void cs_frame_go( void )
{
   //if( cis_line_go <= 2 )
   //   return;
   cis_line_get = line_num = 0;
   cis_line_number = 0;
   cis_line_go = 1;
   CSICR = 0x00;
   CSCON = 0x00;
   _bitCLR( cis_vsync_pif );
   _bitSET( cis_vsync_pie );
   _bitSET( cis_vsync_icr );
}

#if 0
void Delay30ms( void )
{
   register unsigned int i = 0, j = 8;

   do
   {
      while( ++i );
   }
   while( --j );
}
#endif

