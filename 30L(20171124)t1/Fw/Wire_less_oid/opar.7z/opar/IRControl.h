/*******************************************************************
 * Copyright (c) 2010
 * British Virgin Isiands Billion Gold Securities Ltd.
 * File Name    : IRControl.h
 * Author       :
 * Create Date  : Oct. 27, 2010
 * History      :
 * Remark       :
*******************************************************************/
#ifndef _IRControl_H
#define _IRControl_H

#define IR_Max  0X50
#define IR_Min  0X01
#define IR_Max_Cycle 0x4FF


#define ADC_0R 0x2B          //0x202  PWM=0X24
#define ADC_2R 0x4F          //0x22D  PWM=0X28
#define ADC_4R 0x6F          //0x251  PWM=0X2E
#define ADC_6R 0x83         //0x271  PWM=0X38
#define ADC_8R 0x96         //0x285  PWM=0X44
#define ADC_10R 0xAA        //0x298  PWM=0X50

#define ADC_2R_V 0X04
#define ADC_4R_V 0X06
#define ADC_6R_V 0X14
#define ADC_8R_V 0X20
#define ADC_10R_V 0X2C

extern void IR_Init(void);
extern void IR_Close(void);
extern void LeftIR_Level(unsigned int level);
extern void RightIR_Level(unsigned int level);

#endif
