#include "oparcode.h"
#include "sfr.h"

#ifdef __KBCC__
#include <ISD12_DDK.H>
#endif

#ifndef _KB_ASM_

extern __X unsigned int L_Bright;
extern __X unsigned int R_Bright;
extern __X unsigned int C_Bright;
extern __X unsigned int Bright;

extern __X unsigned int Temp_L_Bright;
extern __X unsigned int Temp_R_Bright;
extern __X unsigned int Temp_C_Bright;

extern __X unsigned int BrFlag;

void GetBright(unsigned int i, _NEAR unsigned char* line)
{
	unsigned int m;

	if (i<10)
	{	
		BrFlag =0;
		//C_Bright = 0;
		Temp_L_Bright = 0;
		Temp_R_Bright = 0;
		Temp_C_Bright = 0;
	}
	else if ( (i>=28) && (i<44) )
	{
		for (m=52; m<68; m++)
			Temp_L_Bright+=line[m];
	}
	else if ( (i>=52) && (i<68) )
	{
		for (m=52; m<68; m++)
			Temp_C_Bright+=line[m];
	}
	else if ( (i>=76) && (i<92) )
	{
		for (m=52; m<68; m++)
			Temp_R_Bright+=line[m];
	}
//	else if (i==119)
	else if (i>100)
	{
		if (BrFlag == 0)
		{
			L_Bright = Temp_L_Bright;
			R_Bright = Temp_R_Bright;
			C_Bright = Temp_C_Bright;	
			Bright   = C_Bright/256;
			BrFlag = 1;
		}
	}
}

#else
__asm {
;//void GetBright(unsigned int i, _NEAR unsigned char* line)
;//{

.area _$GetBright(MBC_CODE,REL)
_GetBright::
	LINK #0
	PUSH	R0
	PUSH	R1
	PUSH	R4
	PUSH	X0
	PUSH	X1
	PUSH	DS0
	PUSH	DS1
	
	MOV		DS0, #0
	MOV		DS1, #1

	MOV		R4, [FP+#6]	; i
	MOV		X0, [FP+#8]	; line
	ADD		X0, #52
	MOV		X1, [FP+#8]	; line
	ADD		X1, #68

;//if (i<10)
$L1:
	CMP		R4, #10
	AJMP	IF_UGE, $L2

;//	BrFlag =0;
;//	C_Bright = 0;
;//	Temp_L_Bright = 0;
;//	Temp_R_Bright = 0;
;//	Temp_C_Bright = 0;
	MOV		R1, #0
	MOVX	_BrFlag, R1
	;MOVX	_C_Bright, R1
	MOVX	_Temp_L_Bright, R1
	MOVX	_Temp_R_Bright, R1
	MOVX	_Temp_C_Bright, R1

;//else if ( (i>=28) && (i<44) )
$L2:
	CMP		R4, #28
	AJMP	IF_UL, $L3
	CMP		R4, #44
	AJMP	IF_UGE, $L3

;//		for (m=52; m<68; m++)
;//			Temp_L_Bright+=line[m];
	MOV	R0, #_Temp_L_Bright
	AJMP	$L6

;//else if ( (i>=52) && (i<68) )
$L3:
	CMP		R4, #52
	AJMP	IF_UL, $L4
	CMP		R4, #68
	AJMP	IF_UGE, $L4

;//		for (m=52; m<68; m++)
;//			Temp_C_Bright+=line[m];
	MOV	R0, #_Temp_C_Bright
	AJMP	$L6

;//else if ( (i>=76) && (i<92) )
$L4:
	CMP		R4, #76
	AJMP	IF_UL, $L5
	CMP		R4, #92
	AJMP	IF_UGE, $L5

;//		for (m=52; m<68; m++)
;//			Temp_R_Bright+=line[m];
	MOV	R0, #_Temp_R_Bright
	AJMP	$L6

;//else if (i>100)
$L5:
	CMP		R4, #100
	AJMP	IF_ULE, $L0

;//if (BrFlag == 0)
$L51:
	MOVX	R1, _BrFlag
	CMP		R1, #0
	AJMP	IF_NE, $L0

;//	L_Bright = Temp_L_Bright;
;//	R_Bright = Temp_R_Bright;
;//	C_Bright = Temp_C_Bright;	
;//	Bright   = C_Bright/256;
;//	BrFlag = 1;

	MOVX	R1, _Temp_L_Bright
	MOVX	_L_Bright, R1
	MOVX	R1, _Temp_R_Bright
	MOVX	_R_Bright, R1
	MOVX	R1, _Temp_C_Bright
	MOVX	_C_Bright, R1
	MOVX	R1, _C_Bright
	SR		R1, #8
	MOVX	_Bright, R1
	MOV		R1, #1
	MOVX	_BrFlag, R1

	AJMP	$L0
	
$L6:

	MOV	R1, [R0]
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	ADDB	Rb3, [X0++]
	ADDCB	Rb2, #0
	MOV		[R0], R1

$L0:
	POP	DS1
	POP	DS0
	POP	X1
	POP	X0
	POP	R4
	POP	R1
	POP	R0
	UNLINK
	RETS
}
#endif
//*****************************************************************************
// EOF
//*****************************************************************************