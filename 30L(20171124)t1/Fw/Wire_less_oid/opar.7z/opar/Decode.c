/*******************************************************************
 * Copyright (c) 2010
 * British Virgin Isiands Billion Gold Securities Ltd.
 * File Name    : Decode.c
 * Author       :
 * Create Date  : Oct. 25, 2010
 * History      :
 * Remark       :
*******************************************************************/
//--------------------------------------------------------------------
#include "oparcode.h"
#include "sfr.h"
#ifdef __KBCC__
#include <ISD12_DDK.H>
#endif
#include "668_lib.h"
#include "cis.h"
#include "IRControl.h"
//#include "LED.h"
//#include "apglobal.h"
#include "apManager.h"

//--------------------------------------------------------------------
//--------------------------------------------------------------------
static __X unsigned int FrameFlag = 0;

extern __X unsigned int IR_Level[7][2];
extern __X unsigned int IR_Count;

__X unsigned int Timer2_Flag = 0;
__X unsigned int Timer2_Count = 0;
__X unsigned int Temp = 0;

__X unsigned int L_Bright;
__X unsigned int R_Bright;
__X unsigned int C_Bright;
__X unsigned int Temp_L_Bright;
__X unsigned int Temp_R_Bright;
__X unsigned int Temp_C_Bright;
__X unsigned int BrFlag;

__X unsigned int LowFreqFlag=0;

__X unsigned int usCnt = 0;
__X unsigned int usFlag = 0;

__X unsigned int DecodeCnt=0;
__X unsigned int TempIDCode=0;
__X unsigned int IDCodeBackup=0;
//extern __X unsigned long DACSwitch;
//extern __X unsigned long DECBuffer;

 __X unsigned long DACSwitch;
 __X unsigned long DECBuffer;

//extern __X unsigned int Playback_F;

extern __X unsigned int PlayCode;

//#if (c_enable_mp3 || c_enable_record)

//extern __X unsigned int IDCodeBackup;
//extern __X unsigned int TempIDCode;
//extern __X unsigned int DecodeCnt;

//#endif

//--------------------------------------------------------------------
void Delay(unsigned int count)
{
	unsigned int i;
	for (i=0; i<count; i++);
}
//--------------------------------------------------------------------
unsigned int ImgBright(unsigned char *Img, unsigned int x, unsigned int y)
{
	unsigned int w,h;
	unsigned int Br;

	Br = 0;
	for (h=y; h<(y+16); h++)
	for (w=x; w<(x+16); w++)
	{
		Br += (unsigned int)Img[h*_WIDTH+w];
	}

	return (Br>>8);
}
//--------------------------------------------------------------------
char Decode(void)
{
	char i;
	unsigned int w,h;
	unsigned int y;
	int	temp_data;
	unsigned char *Image;

	if (FrameFlag==0)
		return 0;

	i = 0;

	temp_data = read_cis(cis_buffer_point);

	if ( C_Bright < 10000 )
	{
		IR_Count = 6;
		goto RETRY_IR;
	}

	PlayCode = 0;

	i = barcode( Image, &PlayCode );
	if (i)
	{
		usCnt = 0;
		usFlag = 0;

		if ((PlayCode == 0x02) || (PlayCode == 0x05))
		{
			i = 0;
			goto RETRY_IR;
		}

//#if (c_enable_mp3 || c_enable_record)
		if(IDCodeBackup == PlayCode)
		{
			if(DecodeCnt == 0xff)
				i = 1;
			else
				i = 0;
			DecodeCnt = 0;
		}
		else
		{
			if(DecodeCnt == 0xff) DecodeCnt = 0;
			DecodeCnt++;
			i = 0;
			if (DecodeCnt >= 2)
			{
				if(TempIDCode == PlayCode)
				{
					IDCodeBackup = PlayCode;
					DecodeCnt = 0xff;
				}
				else
					DecodeCnt = 0;
			}
			if(DecodeCnt == 1)
			{
				TempIDCode = PlayCode;
			}
		}
//#endif
		Temp=0;
	}
	else
	{
		#if 0
		if(!usFlag)
		{
 			usCnt++;
			if(usCnt >= 100)
				usFlag=1;
		}
		#endif

	    IR_Count+= 2;
		if(IR_Count > 6)
		{
			if(Temp==0)
			{
				temp_data = (int)(L_Bright-R_Bright);

				if (temp_data>0)
				{
					IR_Count = 1;
				}
				else
				{
					IR_Count = 0;
				}
				Temp=1;
			}
			else
			{
				if((IR_Count%2)==0)
				{
					IR_Count=1;
				}
				else
					IR_Count=0;
				Temp=0;
			}
		}
		//
	}
RETRY_IR:
	FrameFlag = 0;
	RightIR_Level(IR_Level[IR_Count][0]);
	LeftIR_Level(IR_Level[IR_Count][1]);

	return i;
}
//---------------------------------------------------------------------------
void __interrupt Timer2_ISR(void)
{
// Interrupt Service Routin Code
	if (Timer2_Flag)
		Timer2_Count++;
}
//---------------------------------------------------------------------------
// Peripheral specific initialization functions
// Called from the Init_Device() function
void Timer2_Init(void)	// 1ms
{
    SetVector( 0x14, Timer2_ISR );
    TM2PRD = 3000;
    TMR2CR = 0xD002;
    TM2ICR = 0x0031;
}
//--------------------------------------------------------------------
extern _NEAR unsigned int opar_flag;
extern _NEAR unsigned int cis_y_count;
extern _NEAR unsigned char opar_buffer0[120];

extern void DoLineExtraction(unsigned int i, _NEAR unsigned char* line);

__X unsigned int GBInit;
//--------------------------------------------------------------------
void GetBrightLowF(unsigned int i, _NEAR unsigned char* line)
{
	unsigned int m;

	if(GBInit == 0)
	{
		Temp_C_Bright = 0;
		GBInit = 1;
	}
	if(i < 10)
	{
		Temp_C_Bright = 0;
	}
	else if((i >= 48)&&(i < 72))
	{
		for(m = 48; m < 72; m++)
			Temp_C_Bright += line[m];
	}
	else if(i > 100)
	{
		C_Bright = Temp_C_Bright;
	}
}

//--------------------------------------------------------------------
extern void GetBright(unsigned int i, _NEAR unsigned char* line);
__X unsigned int  DecodeBusyFlag;

__X unsigned char opar_buffer[2][120];
extern __X unsigned int LowFreqFlag;

#define CMOS_TIMEOUT	100
extern unsigned short int MBC1002;
//--------------------------------------------------------------------
void GetFrame(void)
{
	unsigned int cis_data;
	unsigned int line;
	__X unsigned char *buf;

	if (FrameFlag)
	{
		return;
	}

	InitDotExtract();

	Timer2_Count = 0;
	Timer2_Flag = 1;
	Timer2_Init();

	GBInit = 0;

	while(1)
	{
		CLEAR_WDT
		/*	
		if (Playback_F!=0)
		{
			//if(DECBuffer <= (DACSwitch + 1))
			if(DECBuffer < (DACSwitch + 1))
				goto RET_CMOS;
		}
		*/
        if(Timer2_Count > CMOS_TIMEOUT)
			break;

		if(MBC1002 > 80)
		{
			FrameFlag = 0;
			break;
		}

		cis_data = CIS_Read_Flag();
		if(cis_data == 0)
		{
			FrameFlag = 1;
			break;
		}
	}
	if(MBC1002 >= 120) {
		__asm("RESET");
		__asm("RESET");
	}

RET_CMOS:
	TMR2CR = 0;
	TM2ICR = 0;

	Timer2_Flag = 0;
}
//--------------------------------------------------------------------
unsigned int  CIS_Check(void)
{
	char i;

	if(FrameFlag == 0)
		return 0;

	if(C_Bright < 10000)
	{
		IR_Count = 6;
	}
	else
	{
		PlayCode = 0;
	}
	FrameFlag = 0;
	return C_Bright;
}
