#define NOW_DATA "2015-08-13" 
