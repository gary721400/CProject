#ifndef	_POINT_G_H_
#define	_POINT_G_

#define OID_TYPE_FLAG_X                 90
#define OID_TYPE_FLAG_Y                 0

#endif 