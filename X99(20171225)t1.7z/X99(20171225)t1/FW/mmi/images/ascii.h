#ifndef	_ASCII_H_
#define	_ASCII_H_

#include "config.h"
#include "stdio.h"

#endif 