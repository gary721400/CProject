//!
//! @file mmi_dummy.h,v
//!
//! Copyright (c) 2004 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief This file defines the MMI common var
//!
//! @version 1.1 snd3-dvk-1_9_5 $Id: mmi_dummy.h,v 1.1 2005/10/03 11:13:20 coger Exp $
//!
//! @todo
//! @bug
//!
#ifndef _mmi_dummy_h_
#define _mmi_dummy_h_


//_____ I N C L U D E S ____________________________________________________


//_____ M A C R O S ________________________________________________________


//_____ D E F I N I T I O N S ______________________________________________


//_____ D E C L A R A T I O N S ____________________________________________


#endif  //! _mmi_dummy_h_
