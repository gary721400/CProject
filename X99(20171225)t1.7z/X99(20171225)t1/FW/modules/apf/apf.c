#ifndef _apf_c_
#define _apf_c_

#include "config.h"
#include "apf.h"

#pragma DATA = APF_DATA
#pragma CODE = APF_CODE

const   U8    g_apf_default_name[] = "apf";

#endif   //_apf_c_
