//!
//! @file lcd_SSD1303.c,v
//!
//! Copyright (c) 2004 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief This file gives definitions of the SSD1303 lcd controller driver functions used in MMI applications.
//!		   Code only implemented if "LCD_CONTROLLER_PART_NUMBER" has been defined with the label "LCD_CONTROLLER_SSD1303".
//!        This definition is to do in the file "conf_lcd.h".
//!		   Note that the SSD1303 is a monochrom lcd with horizontal pages
//!
//! @version 1.25 snd3b-dvk-1_9_3 $Id: lcd_SSD1303.c,v 1.25 2007/07/26 15:01:03 sguyon Exp $
//!
//! @todo
//! @bug
#ifndef _lcd_SSD1303_c_
#define _lcd_SSD1303_c_


//_____ I N C L U D E S ____________________________________________________

#include "config.h"
#include "conf\conf_lcd.h"
#if( LCD_PRESENT == ENABLED )
#if ( LCD_CONTROLLER_PART_NUMBER == LCD_CONTROLLER_SSD1303 )
#include "conf\conf_mmi.h"
#include "conf\conf_oid.h"
#include "drivers\mmi\img_handler.h"
#include "lib_mcu\lcd\lcd_drv.h"
#include "lib_system\unicode\unicode.h"
#include "lib_system\auto_disp\auto_disp.h"
#include "modules\control_access\ctrl_access.h"
#include "mmi\shared\com_var.h"
#include "mmi\kbd\keypad.h"
#include "lcd_SSD1303.h"

#include "sio\com.h"
//#include "lib_mcu\sio\sio_drv.h"
#include "drivers\oid\oid.h"
//#include "modules\mmi_manager\mmgr_kernel.h"
#include "mmi\images\tab_pict.h"


#include <sfr.h>
#include "KBDM9_DDK.H"
#include "KBDM952.H"
#include "fs.h"

#pragma DATA = LCD_SSD1303_DATA
#pragma CODE = LCD_SSD1303_CODE


ImageDeclareType( LCD_SSD1303_TEMP_CODE01 );

ImageDeclareType( UNICODE_TEMP_CODE03 );

ImageDeclareType( IMG_HANDLER_TEMP_CODE00 );


//! Global x and y variables for display
U8  _MEM_TYPE_SLOW_   lcd_g_lcd_x = 0;
U8  _MEM_TYPE_SLOW_   lcd_g_lcd_y = 0;

//! Global one-bit variable for the merging or not of superimposed displays
Bool b_merging = FALSE;

//! Set in "lcd_puts()" if effective text scrolling done
//! and only read by MMI via the macro "Lcd_have_scrolling_been_effective()"
Bool b_scrolling_mode_effective;

//! Variable used in "lcd_puts()" to define the viewport
_MEM_TYPE_SLOW_ lcd_viewport lcd_g_viewport = {LCD_WIDTH - 1};

//! Pointer used in "lcd_puts()" for the text scrolling
st_txt_scrolling _MEM_TYPE_SLOW_*ptr_txt_scrolling_prm = NULL;

//! Timer to delay the backlight switching off
//! Only declared if backlight authorized
#if (BACKLIGHT == ENABLE)
   U32 _MEM_TYPE_SLOW_ g_timer_backlight = 0x00;

//! Allow dynamic disable of backlight
   U8 _MEM_TYPE_SLOW_ g_backlight_en = TRUE;
#endif

#if (BACKLIGHT == ENABLE)
_MEM_TYPE_SLOW_ U8 g_mmi_lcd_backlight_off = FALSE;
#endif

Bool  lcd_g_inverse = FALSE;

const U8 ascii8_uncode[  ][ 6 ] =
{
   { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 },   //' '
   { 0x00, 0x00, 0x4F, 0x00, 0x00, 0x00 },   //'!'
   { 0x00, 0x07, 0x00, 0x07, 0x00, 0x00 },   //'"'
   { 0x14, 0x7F, 0x14, 0x7F, 0x14, 0x00 },   //'#'
   { 0x24, 0x2A, 0x7F, 0x2A, 0x12, 0x00 },   //'$'
   { 0x23, 0x13, 0x08, 0x64, 0x62, 0x00 },   //'%'
   { 0x36, 0x49, 0x55, 0x22, 0x50, 0x00 },   //'&'
   { 0x00, 0x05, 0x03, 0x00, 0x00, 0x00 },   //'''
   { 0x00, 0x1C, 0x22, 0x41, 0x00, 0x00 },   //'('
   { 0x00, 0x41, 0x22, 0x1C, 0x00, 0x00 },   //')'
   { 0x14, 0x08, 0x3E, 0x08, 0x14, 0x00 },   //'*'
   { 0x08, 0x08, 0x3E, 0x08, 0x08, 0x00 },   //'+'
   { 0x00, 0x50, 0x30, 0x00, 0x00, 0x00 },   //','
   { 0x08, 0x08, 0x08, 0x08, 0x08, 0x00 },   //'-'
   { 0x00, 0x60, 0x60, 0x00, 0x00, 0x00 },   //'.'
   { 0x20, 0x10, 0x08, 0x04, 0x02, 0x00 },   //'/'
   
   { 0x3E, 0x51, 0x49, 0x45, 0x3E, 0x00 },   //'0'
   { 0x00, 0x42, 0x7F, 0x40, 0x00, 0x00 },   //'1'
   { 0x42, 0x61, 0x51, 0x49, 0x46, 0x00 },   //'2'
   { 0x21, 0x41, 0x45, 0x4B, 0x31, 0x00 },   //'3'
   { 0x18, 0x14, 0x12, 0x7F, 0x10, 0x00 },   //'4'
   { 0x27, 0x45, 0x45, 0x45, 0x39, 0x00 },   //'5'
   { 0x3C, 0x4A, 0x49, 0x49, 0x30, 0x00 },   //'6'
   { 0x01, 0x71, 0x09, 0x05, 0x03, 0x00 },   //'7'
   { 0x36, 0x49, 0x49, 0x49, 0x36, 0x00 },   //'8'
   { 0x06, 0x49, 0x49, 0x29, 0x1E, 0x00 },   //'9'
   { 0x00, 0x36, 0x36, 0x00, 0x00, 0x00 },   //':'
   { 0x00, 0x56, 0x36, 0x00, 0x00, 0x00 },   //';'
   { 0x08, 0x14, 0x22, 0x40, 0x00, 0x00 },   //'<'
   { 0x14, 0x14, 0x14, 0x14, 0x14, 0x00 },   //'='
   { 0x00, 0x41, 0x22, 0x14, 0x08, 0x00 },   //'>'
   { 0x02, 0x01, 0x51, 0x09, 0x06, 0x00 },   //'?'
   
   { 0x32, 0x49, 0x79, 0x41, 0x3E, 0x00 },   //'@'
   { 0x7E, 0x11, 0x11, 0x11, 0x7E, 0x00 },   //'A'
   { 0x7F, 0x49, 0x49, 0x49, 0x36, 0x00 },   //'B'
   { 0x3E, 0x41, 0x41, 0x41, 0x22, 0x00 },   //'C'
   { 0x7F, 0x41, 0x41, 0x22, 0x1C, 0x00 },   //'D'
   { 0x7F, 0x49, 0x49, 0x49, 0x41, 0x00 },   //'E'
   { 0x7F, 0x09, 0x09, 0x09, 0x01, 0x00 },   //'F'
   { 0x3E, 0x41, 0x49, 0x49, 0x7A, 0x00 },   //'G'
   { 0x7F, 0x08, 0x08, 0x08, 0x7F, 0x00 },   //'H'
   { 0x00, 0x41, 0x7F, 0x41, 0x00, 0x00 },   //'I'
   { 0x20, 0x40, 0x41, 0x3F, 0x01, 0x00 },   //'J'
   { 0x7F, 0x08, 0x14, 0x22, 0x41, 0x00 },   //'K'
   { 0x7F, 0x40, 0x40, 0x40, 0x40, 0x00 },   //'L'
   { 0x7F, 0x02, 0x0C, 0x02, 0x7F, 0x00 },   //'M'
   { 0x7F, 0x04, 0x08, 0x10, 0x7F, 0x00 },   //'N'
   { 0x3E, 0x41, 0x41, 0x41, 0x3E, 0x00 },   //'O'
   
   { 0x7F, 0x09, 0x09, 0x09, 0x06, 0x00 },   //'P'
   { 0x3E, 0x41, 0x51, 0x21, 0x5E, 0x00 },   //'Q'
   { 0x7F, 0x09, 0x19, 0x29, 0x46, 0x00 },   //'R'
   { 0x46, 0x49, 0x49, 0x49, 0x31, 0x00 },   //'S'
   { 0x01, 0x01, 0x7F, 0x01, 0x01, 0x00 },   //'T'
   { 0x3F, 0x40, 0x40, 0x40, 0x3F, 0x00 },   //'U'
   { 0x1F, 0x20, 0x40, 0x20, 0x1F, 0x00 },   //'V'
   { 0x3F, 0x40, 0x38, 0x40, 0x3F, 0x00 },   //'W'
   { 0x63, 0x14, 0x08, 0x14, 0x63, 0x00 },   //'X'
   { 0x07, 0x08, 0x70, 0x08, 0x07, 0x00 },   //'Y'
   { 0x61, 0x51, 0x49, 0x45, 0x43, 0x00 },   //'Z'
   { 0x00, 0x7F, 0x41, 0x41, 0x00, 0x00 },   //'['
   { 0x02, 0x04, 0x08, 0x10, 0x20, 0x00 },   //'\'
   { 0x00, 0x41, 0x41, 0x7F, 0x00, 0x00 },   //']'
   { 0x04, 0x02, 0x01, 0x02, 0x04, 0x00 },   //'^'
   { 0x40, 0x40, 0x40, 0x40, 0x40, 0x00 },   //'_'
   
   { 0x01, 0x02, 0x04, 0x00, 0x00, 0x00 },   //'`'
   { 0x20, 0x54, 0x54, 0x54, 0x78, 0x00 },   //'a'
   { 0x7F, 0x48, 0x44, 0x44, 0x38, 0x00 },   //'b'
   { 0x38, 0x44, 0x44, 0x44, 0x20, 0x00 },   //'c'
   { 0x38, 0x44, 0x44, 0x48, 0x7F, 0x00 },   //'d'
   { 0x38, 0x54, 0x54, 0x54, 0x18, 0x00 },   //'e'
   { 0x08, 0x7E, 0x09, 0x01, 0x02, 0x00 },   //'f'
   { 0x06, 0x49, 0x49, 0x49, 0x3F, 0x00 },   //'g'
   { 0x7F, 0x08, 0x04, 0x04, 0x78, 0x00 },   //'h'
   { 0x00, 0x44, 0x7D, 0x40, 0x00, 0x00 },   //'i'
   { 0x20, 0x40, 0x44, 0x3D, 0x00, 0x00 },   //'j'
   { 0x7F, 0x10, 0x28, 0x44, 0x00, 0x00 },   //'k'
   { 0x00, 0x41, 0x7F, 0x40, 0x00, 0x00 },   //'l'
   { 0x7C, 0x04, 0x18, 0x04, 0x7C, 0x00 },   //'m'
   { 0x7C, 0x08, 0x04, 0x04, 0x78, 0x00 },   //'n'
   { 0x38, 0x44, 0x44, 0x44, 0x38, 0x00 },   //'o'
   
   { 0x7C, 0x14, 0x14, 0x14, 0x08, 0x00 },   //'p'
   { 0x08, 0x14, 0x14, 0x18, 0x7C, 0x00 },   //'q'
   { 0x7C, 0x08, 0x04, 0x04, 0x08, 0x00 },   //'r'
   { 0x48, 0x54, 0x54, 0x54, 0x20, 0x00 },   //'s'
   { 0x04, 0x3F, 0x44, 0x40, 0x20, 0x00 },   //'t'
   { 0x3C, 0x40, 0x40, 0x20, 0x7C, 0x00 },   //'u'
   { 0x1C, 0x20, 0x40, 0x20, 0x1C, 0x00 },   //'v'
   { 0x3C, 0x40, 0x30, 0x40, 0x3C, 0x00 },   //'w'
   { 0x44, 0x28, 0x10, 0x28, 0x44, 0x00 },   //'x'
   { 0x0C, 0x50, 0x50, 0x50, 0x3C, 0x00 },   //'y'
   { 0x44, 0x64, 0x54, 0x4C, 0x44, 0x00 },   //'z'
   { 0x00, 0x08, 0x36, 0x41, 0x00, 0x00 },   //'{'
   { 0x00, 0x00, 0x7F, 0x00, 0x00, 0x00 },   //'|'
   { 0x00, 0x41, 0x36, 0x08, 0x00, 0x00 },   //'}'
   { 0x02, 0x01, 0x02, 0x04, 0x02, 0x00 },   //'~'
   { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 }    //DEL
};


//_____ P R I V A T E   D E C L A R A T I O N S ____________________________
static _MEM_TYPE_SLOW_ U8 lcd_g_page          = 0;
static _MEM_TYPE_SLOW_ U8 lcd_g_shift_in_page = 0;
static _MEM_TYPE_SLOW_ U8 lcd_g_line          = 0;
static Bool b_merging_old;

#if( LCD_SCREEN_BUFFER == ENABLED )
static U8 _MEM_TYPE_SLOW_   s_screen_buffer[NB_LCD_PAGES*NB_LCD_LINES];
static U8 _MEM_TYPE_SLOW_*  s_ptr_screen_buffer;
static U8 _MEM_TYPE_SLOW_   s_display_data_read;
#endif

static U8 const PosBin[8]   = {0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};

// Table MaskBin
//  used on right display boundary : mask to keep the left part only
//  input    : the MSB position of the display data used
//  output   : the mask giving the consecutive bits NOT used by the display data
//  examples : bit7 is MSB, so bit0 -> 7 used to code display data, so no bit free, return 0
//           : bit4 is MSB, so bit0 -> 4 used to code display data, so bit5 -> 7 are free, return 0xE0
static U8 const MaskBin[8]  = {0xFE,0xFC,0xF8,0xF0,0xE0,0xC0,0x80,0x00};

// Table MaskBin2
//  used on left display boundary : mask to keep the right part only
//  input    : the MSB position of the display data used
//  output   : the mask giving the consecutive bits used by the display data
//  examples : bit7 is MSB, so bit0 -> 6 used to code display data, so bit7 free, return 0x01
//           : bit4 is MSB, so bit0 -> 3 used to code display data, so bit4 -> 7 are free, return 0x0F
//static U8 const MaskBin2[8] = {0xFF,0x7F,0x3F,0x1F,0x0F,0x07,0x03,0x01};


//_____ P R I V A T E   D E C L A R A T I O N S ____________________________
U8 lcd_get_nb_pages(        U8 nb_pixels );
U8 lcd_get_start_page_mask( U8 nb_pixels );
U8 lcd_get_end_page_mask(   U8 nb_pixels );
U8 lcd_get_end_page_ws(     U8 nb_pixels );
U8 lcd_get_end_page(        U8 nb_pixels );
U8 lcd_get_nb_lines(        U8 nb_pixels );

#if (BACKLIGHT == ENABLE)
Bool  g_b_lcd_backlight_off = FALSE;
#endif

//add by xuanyu
void  lcd_puts_simple      ( U8* string );


//_____ D E F I N I T I O N S ______________________________________________

#if 1
void Lcd_set_cursor( void )
{
   lcd_write_command( LCD_POSY0 | lcd_g_page );

   /* Write the 4 lower bits of the line value */
   lcd_write_command( LCD_POSX0 | ( 0x0F &( lcd_g_line + 2 )) );

	/* Write the 4 upper bits of the line value */
   lcd_write_command( LCD_POSX1 | (( lcd_g_line + 2 )>> 4) );

   Lcd_set_ptr_screen_buffer();
}


void  Lcd_goto_x( U8 x0 )
{
   /* Store the new X-coordinate in the dedicated global variable */
   lcd_g_lcd_x = (x0);

   /* Write the new LCD current line to the controller */
   Lcd_set_line( lcd_g_lcd_x );
}


void Lcd_goto_y( U8 y0 )
{
   /* Store the new Y-coordinate in the dedicated global variable */
   lcd_g_lcd_y = (y0);

   /* Write the new LCD current page to the controller */
   //Lcd_set_page( lcd_g_lcd_y /8 );
   Lcd_set_page( lcd_g_lcd_y >> 3 );

   /* Get the shifting to apply to the display data */
   //lcd_g_shift_in_page = PosBin[ lcd_g_lcd_y %8 ];
   lcd_g_shift_in_page = PosBin[ lcd_g_lcd_y & 0x07 ];
}
#endif


//! Write a data in the LCD controller display ram
void Lcd_write_display_data( U8 val )
{
   //SetStorageBusy();
   Lcd_drv_enable_interface();
   /* Waiting display interface available to lauch a writing */
   Lcd_drv_test_lcbusy();

   /* Transmit display data */
   /*Lcd_drv_write_data(val);*/
   Lcd_drv_write_data(( lcd_g_inverse )?( ~( val )):( val ));
   Lcd_drv_test_lcbusy();
   Lcd_drv_disable_interface();
   //ClearStorageBusy();
}

//! Write a command to the LCD controller
void Lcd_write_command( U8 cmd )
{
   //SetStorageBusy();
   Lcd_drv_enable_interface();
   
   /* Waiting display interface available to lauch a writing */
   Lcd_drv_test_lcbusy();

   /* Select instruction register */
   Lcd_drv_select_instr_reg();

   /* Transmit command value */
   Lcd_drv_write_cmd(cmd);

   /* Data register access by default */
   /* ! MUST BE ALWAYS IMPLEMENTED HERE AS LAST INSTRUCTION ! */
   Lcd_drv_select_data_reg();

   Lcd_drv_test_lcbusy();
   
   Lcd_drv_disable_interface();
   //ClearStorageBusy();
}
#if 0
//! Write a display data in the LCD controller or in the screen buffer
#if( LCD_SCREEN_BUFFER == DISABLED )
//! Write a data in the LCD controller display ram
//extern   Bool  lcd_g_inverse;
#  define Lcd_write_display_data(val)                                \
   {                                                                 \
      /* Waiting display interface available to lauch a writing */   \
      Lcd_drv_test_lcbusy();                                         \
                                                                     \
      /* Transmit display data */                                    \
      /*Lcd_drv_write_data(val);*/                                   \
      Lcd_drv_write_data(( lcd_g_inverse )?( ~( val )):( val ));     \
   }
#else
   //! Write a data in the screen buffer
#  define Lcd_write_display_data(val)                                \
   {                                                                 \
      *(s_ptr_screen_buffer++) = (val);                              \
   }
#endif

//! Read a display data from the LCD controller or the screen buffer
#if( LCD_SCREEN_BUFFER == DISABLED )
   //! The read from the LCD controller display ram is done in two steps :
   //!   1) A read request is to sent to the controller via the macro
   //!      "Lcd_read_display_data()"
   //!   2) The read value is got with the help of a second macro
   //!      "display_data_read"
   //! These two macros avoids the call of a unique function that would be slower in execution.
#  define Lcd_read_display_data()                                       \
{                                                                       \
   /* Waiting display interface available to lauch a writing */         \
   Lcd_drv_test_lcbusy();                                               \
                                                                        \
   /* Set the read command */                                           \
   Lcd_drv_set_read_command();                                          \
                                                                        \
   /* Waiting display interface available to get a correct reading  */  \
   Lcd_drv_test_lcbusy();                                               \
                                                                        \
   /* Get the display data by adressing Lcd_drv_display_data_read() */  \
   /* just after the implementation of this macro                   */  \
}
#  define display_data_read             0//Lcd_drv_read_data()
#else
   //! The read from the screen buffer is also done in the two steps 
   //! defined above in order to keep a code compatibility
   //!   1) "Lcd_read_display_data()" is an empty macro
   //!   2) The read value is got with the help of a second macro
   //!      "display_data_read"
   //! These two macros avoids the call of a unique function that would be slower in execution.
#  define Lcd_read_display_data()
#  define display_data_read             *(s_ptr_screen_buffer)
#endif
#endif

//! lcd_write_command
//!
//! To write a command to the LCD controller.
//! 
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 cmd : the command value to write
//!
//! @return none
//!
void lcd_write_command( U8 cmd )
{
   Lcd_write_command( cmd );
}
//#define  lcd_write_command( cmd )   Lcd_write_command( cmd )

//! lcd_get_nb_pages
//!
//! To get the number of 8-bit lcd pages from the picture height or width in pixels
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd pages
//!
//! @return U8: number of lcd pages
//!
U8 lcd_get_nb_pages( U8 nb_pixels )
{
	//return( (nb_pixels -1) / 8 + 1 );
	return(((nb_pixels -1)>> 3 )+ 1 );
}


#pragma CODE = LCD_SSD1303_TEMP_CODE01

//! lcd_get_nb_lines
//!
//! To get the number of lines that could be displayed
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd lines
//!
//! @return U8: number of lcd lines
//!
U8 lcd_get_nb_lines( U8 nb_pixels )
{
	if( Lcd_get_line() + nb_pixels > NB_LCD_LINES )
		return( NB_LCD_LINES - Lcd_get_line() );
	else
		return( nb_pixels ); 
}


#pragma CODE = LCD_SSD1303_CODE

//! lcd_get_end_page_ws (ws as Without Shifting)
//!
//! To get the index of the end page from the start page and the number of pixels 
//! along lcd pages without shifting-in-page
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd pages
//!
//! @return U8: number of lcd pages
//!
U8 lcd_get_end_page_ws( U8 nb_pixels )
{
	U8 end_page;   

	end_page = Lcd_get_page() + lcd_get_nb_pages( nb_pixels ) -1;

	if (end_page >= NB_LCD_PAGES )
	 	return( NB_LCD_PAGES - 1 );
	else
		return( end_page );
}

//! lcd_get_end_page 
//!
//! To get the index of the end page from the start page and the number of pixels 
//! along lcd pages with shifting-in-page
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd pages
//!
//! @return U8: number of lcd pages
//!
U8 lcd_get_end_page( U8 nb_pixels )
{
	U8 end_page;

   	//end_page = ( Lcd_get_y() + nb_pixels -1 ) / 8;
   	end_page = ( Lcd_get_y() + nb_pixels -1 )>> 3;

   	if ( end_page >= NB_LCD_PAGES )
		return( NB_LCD_PAGES - 1 );
	else
		return( end_page );
}

//! lcd_get_start_page_mask
//!
//! To get the mask for the start page in which begins the display of a picture
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd pages
//!
//! @return U8: binary mask
//!
U8 lcd_get_start_page_mask( U8 nb_pixels )
{
	if ( Lcd_is_merging() )
		return( 0xFF );
   	else if ( nb_pixels < 8 )
		return( ( Lcd_get_shift_in_page() * (PosBin[nb_pixels] - 1) ) ^ 0xFF );
   	else
		return( Lcd_get_shift_in_page() - 1 );
}

//! lcd_get_end_page_mask
//!
//! To get the mask for the end page in which ends the display of a picture
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 nb_pixels: the number of pixels along lcd pages
//!
//! @return U8: binary mask
//!
U8 lcd_get_end_page_mask( U8 nb_pixels )
{
	if (Lcd_is_merging())
		return( 0xff );
	else
		//return( MaskBin[ (Lcd_get_y() + nb_pixels - 1) % 8 ] );
		return( MaskBin[ (Lcd_get_y() + nb_pixels - 1) & 7 ] );
}


#pragma CODE = LCD_SSD1303_TEMP_CODE01

//! lcd_goto_x
//!
//! To set the new X-coordinate of the cursor position
//! This function is dedicated to be called by higher level files than lcd_controller.c/h
//! Call of this routine wastes time but enables to save bytes of program memory compared to the macro
//! Moreover, the function implements a boundary test, not integrated in the macro
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 x0: the new X-coordinate
//!
//! @return none
//!
void lcd_goto_x( U8 x0 )
{
   // Check if the X-coordinate is out of boundary
	if ( x0 >= LCD_WIDTH )
		x0 = 0;

   	Lcd_goto_x( x0 );
}

#if 0
//! lcd_goto_y
//!
//! To set the new Y-coordinate of the cursor position
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 y0: the new Y-coordinate
//!
//! @return none
//!
void lcd_goto_y( U8 y0 )
{
   // Check if the Y-coordinate is out of boundary
   if ( y0 >= LCD_HEIGHT )
      y0 = 0;

   Lcd_goto_y( y0 );
}
#endif


#pragma CODE = LCD_SSD1303_CODE

//! lcd_goto_xy
//!
//! To set the new coordinates of the cursor position
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param U8 x0: the new X-coordinate
//! @param U8 y0: the new Y-coordinate
//!
//! @return none
//!
void lcd_goto_xy( U8 x0, U8 y0 )
{
   // Check if the X-coordinate is out of boundary
   if ( x0 >= LCD_WIDTH )
      x0 = 0;

   Lcd_goto_x( x0 );

   // Check if the Y-coordinate is out of boundary
   if ( y0 >= LCD_HEIGHT )
      y0 = 0;

   Lcd_goto_y( y0 );
}


#pragma CODE = LCD_SSD1303_TEMP_CODE02

//! lcd_clear_screen
//!
//! Clear the LCD screen entirely
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param none
//!
//! @return none
//!
void lcd_clear_screen(void)
{
	lcd_clear_part_of_screen( 0, 0, LCD_WIDTH, LCD_HEIGHT);
}

//! lcd_clear_part_of_screen
//!
//! Clear the screen partially
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  U8 x0: X-coordinate of the start point
//!         U8 y0: Y-coordinate of the start point
//!         U8 width : area width to clear
//!         U8 height: area height to clear
//! @return none

// Drawing direction
//      (0,0) __________
//           |          |
//           | |    /|  |
//           | |   / |  |
//           | |  /  |  |
//           | | /   |  |
//           | |/   \|/ |
//           |__________|

void lcd_clear_part_of_screen(U8 x0, U8 y0, U8 width, U8 height)
{
   U8 _MEM_TYPE_MEDFAST_ mask;
   U8 _MEM_TYPE_SLOW_    end_page_mask;
   U8 _MEM_TYPE_SLOW_    curr_page;
   U8 _MEM_TYPE_SLOW_    end_page;
   U8 _MEM_TYPE_MEDFAST_ line;

   Lcd_save_status_merging();
   Lcd_unset_merging();
   // Unset merging to get proper mask with the functions 
   // "lcd_get_start_page_mask()" and "lcd_get_end_page_mask()"


   // Set the new cursor position
   lcd_goto_xy(x0, y0);


   #define NB_LINES  width
   // "end_page_ws" has got the index of the end page without shifting-in-page
   end_page = lcd_get_end_page( height );

   #define START_MASK  lcd_get_start_page_mask(  height );
   #define END_MASK    lcd_get_end_page_mask(    height );


   // WARNING : all the functions "lcd_get_start_page_mask()", "lcd_get_end_page_mask()", 
   //           "lcd_get_end_page()" must be called before the loop begins.
   //           Why? Because the cursor coordinates are changed in the loop

   // The different values taken by the variable "mask"
   // if      (curr_page == Lcd_get_page())   mask = START_MASK;
   // else if (curr_page == end_page      )   mask = end_page_mask;
   // else                                    mask = 0; 

   curr_page = Lcd_get_page();
   mask      = START_MASK;
   end_page_mask  = END_MASK;

   for(; curr_page <= end_page; curr_page++ )
   {
      Lcd_set_page( curr_page      );
      Lcd_set_line( Lcd_get_line() );
      Lcd_set_cursor();

      if( curr_page == end_page )  
      { mask = end_page_mask; }


      line = NB_LINES; // Init the loop variable

      if( mask != 0 )
      { // curr_page == start_page or curr_page == end_page
         for(; line != 0; line-- )
         {
            //Lcd_dummy_read();
            //Lcd_read_display_data();
            Lcd_set_cursor();
            //Lcd_write_display_data( display_data_read & mask );
            Lcd_write_display_data( display_data_read );
         }
         mask = 0;
      }
      else
      {
         for(; line != 0; line-- )
         {
            Lcd_write_display_data( 0 );
         }
      }
   }

   // Restore the status that had the bit b_merging just before the calling of this function
   Lcd_restore_status_merging();

   // Require the display of the new built screen
   Lcd_new_screen_to_display();

   #undef NB_LINES
   #undef START_MASK
   #undef END_MASK
}

#if 0
//! @brief lcd_set_dot
//!
//! Display a dot on the LCD screen
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param   U8 x0: X-coordinate of the dot to display
//!          U8 y0: Y-coordinate of the dot to display
//!
//! @return none
//!
void lcd_set_dot(const U8 x0, const U8 y0)
{
   U8 disp_data;

   lcd_goto_xy(x0, y0);
   Lcd_set_cursor();

   // The bit mask to set properly the dot is already elaborated by the call of Lcd_goto_xy(x0, y0);
   Lcd_dummy_read();
   Lcd_read_display_data();
   disp_data = Lcd_get_shift_in_page() | display_data_read;
   Lcd_set_cursor();
   Lcd_write_display_data( disp_data );

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
}
#endif

#if 0//(GAME_SNAKE == ENABLE)
//! @brief lcd_toggle_dot
//!
//! Set/Remove a dot on the LCD screen
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param   U8 x0: X-coordinate of the dot to display
//!          U8 y0: Y-coordinate of the dot to display
//!
//! @return none
//!
void lcd_toggle_dot(const U8 x0, const U8 y0)
{
   U8 disp_data;

   lcd_goto_xy(x0, y0);
   Lcd_set_cursor();

   // The bit mask to set properly the dot is already elaborated by the call of Lcd_goto_xy(x0, y0);
   Lcd_dummy_read();
   Lcd_read_display_data();
   disp_data = Lcd_get_shift_in_page() ^ display_data_read;
   Lcd_write_display_data( disp_data );

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
}
#endif   // #if (GAME_SNAKE == ENABLE)


#pragma CODE = LCD_SSD1303_CODE

//! @brief lcd_draw_picture
//!
//! Draw a picture on the LCD screen
//! by merging if macro Lcd_setMerging() run before this function
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  U8 x0         : start x-coordinate
//!         U8 y0         : start y-coordinate
//!         U32 IDP       : ID of the picture to display
//! @return none

// Drawing direction
//      (0,0) __________
//           |          |
//           | |    /|  |
//           | |   / |  |
//           | |  /  |  |
//           | | /   |  |
//           | |/   \|/ |
//           |__________|
void lcd_draw_picture( U8 x0, U8 y0, U32 IDP )
{
   Bool b_transparent_mode = FALSE;
   Bool b_animation_mode   = FALSE;
   Bool b_suppl_page       = FALSE;
   _MEM_TYPE_SLOW_ U8  nb_lines;
   _MEM_TYPE_SLOW_ U8  start_page;      // Lcd page that will contain the top-left pixel of the picture to draw
   _MEM_TYPE_SLOW_ U8  end_page_ws;     // Lcd page that could contain the bottom-right pixel of the picture to draw 
                                        //  without pixel shifting 
   _MEM_TYPE_SLOW_ U8  start_page_mask; // Mask of the lcd page that will contain the top-left pixel of the picture to draw 
                                        // It will be used to clear the screen area in which the picture will be drawn
   _MEM_TYPE_SLOW_ U8  end_page_mask;   // Mask of the lcd page that will contain the bottom-right pixel of the picture to draw 
                                        // It will be used to clear the screen area in which the picture will be drawn
   _MEM_TYPE_SLOW_ U8  prev_transp_mask;



   // The 3 following unions "v*" declares variables which are not used at the same time,
   // but in separate code sections. 
   // Thus this enables to save bytes and to get explicit name for these variables
   union
   {
      U8 format;
      U8 height;
      U8 curr_page;
   }v0;

   union
   {
      S8 temp;
      U8 end_page;
      U8 prev_disp_data;
   }_MEM_TYPE_SLOW_ v1;

   union
   {
      U32 log_addr;
      struct
      {
         U16 pict_disp_data;
         U16 transp_mask;
      }st;
   }_MEM_TYPE_SLOW_ v2;

   #define IDX_SUBIMG   LSB0(v2.log_addr)


   
   // Set the origin coordinates where the picture must be displayed
   lcd_goto_xy(x0, y0);

   if( !g_b_animation )
   {
      SDKLoadCode( IMG_HANDLER_TEMP_CODE00 );
      Ih_open_picture_access();
   }
   Ih_select_picture(IDP);


   // Get the format of the picture
   v0.format = Ih_get_picture_data();

   // Transparency format
   if( 0 != (v0.format & 0x01) )
   {
      b_transparent_mode = TRUE;
   }
   // Animation format
   if( 0 != (v0.format & 0x02) )
   {   
      b_animation_mode = TRUE;
      // Get the number of sub-images that compose the animation picture with "Ih_get_picture_data()"
      // and then check that the sub-images index value is not out of boundaries.
      IDX_SUBIMG = ad_g_extra_param;
      v1.temp = Ih_get_picture_data() - ad_g_extra_param;
      // Overflow on the sub-images index, so correction done
      if( v1.temp <= 0 )
      {
         IDX_SUBIMG -= (v1.temp+1);
      }
      // Last sub-image of the animation to draw
      else if( v1.temp == 1 )
      {
         // Return information : end of animation
         ad_g_extra_param |= AD_MASK_END_ANIM;
      }
   }

   // Get the width and the height of the picture
   nb_lines  = Ih_get_picture_data();
   v0.height = Ih_get_picture_data();

   // Set current NF pointer to the physical address of the first pixel to draw
   if( b_animation_mode )
   {
      v2.log_addr  = (U16)(nb_lines * lcd_get_nb_pages(v0.height)) * IDX_SUBIMG;
      v2.log_addr += IDP+3+1;
      nfloader_compute_physic_addr( v2.log_addr );
      //nfloader_open_page_for_reading_via_register();
   }

   // "end_page_ws" has got the index of the end page without shifting-in-page
   end_page_ws = lcd_get_end_page_ws( v0.height );
   // "END_PAGE" has got the index of the end page with shifting-in-page
   v1.end_page = lcd_get_end_page(    v0.height );
   // BE CAREFUL : start_page_mask == end_page_mask == 0xff if Merging set
   start_page_mask  = lcd_get_start_page_mask(  v0.height ); 
   end_page_mask    = lcd_get_end_page_mask(    v0.height );


   if( TRUE == b_transparent_mode )
   {
      Lcd_save_status_merging(); //Save the current status of merging
      Lcd_set_merging();         //Merging is required here for the transparent mode,
                                 // set after the calculation of start_page_mask, end_page_mask
   }


   if( v1.end_page != end_page_ws )
   { // A supplementary page is required with the shifting-in-page for the display of this picture
      if ( v1.end_page < NB_LCD_PAGES )
      { // The supplementary page is allowed because of no danger of page overflow
         b_suppl_page = TRUE;
      }
   }

   start_page = Lcd_get_page();


   for(; nb_lines != 0; nb_lines--)
   {
      v0.curr_page = start_page;
      Lcd_set_page( v0.curr_page );
      Lcd_set_cursor();

      // Get the display data byte of the start page in which the drawing of the picture starts.
      // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
      // the picture by a OR operation.
      // The clearing of these bits is done with the help of the mask "start_page_mask"
      //Lcd_dummy_read();
      //Lcd_read_display_data();
      //v1.prev_disp_data = display_data_read & start_page_mask;
      v1.prev_disp_data = display_data_read;
      prev_transp_mask  = 0xff;


      while( 1 )
      {
         if( v0.curr_page > end_page_ws )   break;

         v2.st.pict_disp_data       = (U16)( Ih_get_picture_data() * Lcd_get_shift_in_page() );
         LSB(v2.st.pict_disp_data) |= v1.prev_disp_data;
         v1.prev_disp_data    = MSB(v2.st.pict_disp_data);


         if( TRUE == b_transparent_mode )
         {
            v2.st.transp_mask       = (U16)( Ih_get_picture_data() * Lcd_get_shift_in_page() );
            v2.st.transp_mask      ^= 0xffffu;   
            LSB(v2.st.transp_mask) &= prev_transp_mask;
            prev_transp_mask        = MSB(v2.st.transp_mask);
         }


         if( v0.curr_page == end_page_ws )
         {
            if( start_page != end_page_ws )
            { // Number of pages > 1
               if( FALSE == b_suppl_page )
               { //The picture doesn't require a supplementary building of page,
                 //thus the mixing of the end part of the picture is to do right now
                  v1.prev_disp_data = LSB(v2.st.pict_disp_data);
                  prev_transp_mask  = LSB(v2.st.transp_mask);
                  break;
               }
            }
         }         
         
         
         /*if( Lcd_is_merging() )
         {
            Lcd_dummy_read();
            Lcd_read_display_data();
            LSB(v2.st.pict_disp_data) |= display_data_read & LSB(v2.st.transp_mask);
         }*/

         Lcd_set_cursor();
         Lcd_write_display_data( LSB(v2.st.pict_disp_data) );
         Lcd_set_line( Lcd_get_line() );
         Lcd_set_page( ++v0.curr_page );
         //Lcd_set_cursor();
      } 

      // Get the display data byte of the end page in which the drawing of the picture ends
      // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
      // the picture by a OR operation.
      // The clearing of these bits is done with the help of the mask "end_page_mask"
      // The mixing of the end part of the picture to display and the background is done here if
      // the number of pages is greater than 1 or a supplementary page exists.
      // Indeed, in the case where the number of pages is 1 and no supplementary page, 
      // this mixing has already be done with the help of the mask "start_page_mask" above.
      if( ( start_page != end_page_ws ) || ( TRUE == b_suppl_page ) )
      {
         if( TRUE == b_transparent_mode )  
         { end_page_mask = prev_transp_mask; }

         //Lcd_dummy_read();
         //Lcd_read_display_data();
         Lcd_set_cursor();
         //Lcd_write_display_data( v1.prev_disp_data | ( display_data_read & end_page_mask ) );
         Lcd_write_display_data( v1.prev_disp_data );
      }

      Lcd_set_line( Lcd_get_line()+1 );
   }

   Ih_end_picture_access();

   if( TRUE == b_transparent_mode )
   {
      Lcd_restore_status_merging(); //Restore the previous status of merging
   }

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
}


//! @brief lcd_puts
//!
//! Display text on the LCD screen with the option scrolling mode
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  const U8* string : string to display with scrolling from right to left if active
//!
//! @return none

// Drawing direction
//      (0,0) __________
//           |          |
//           | |    /|  |
//           | |   / |  |
//           | |  /  |  |
//           | | /   |  |
//           | |/   \|/ |
//           |__________|

void lcd_puts( U8* string )
{
#if 0
   Bool b_suppl_page;
   Bool b_scrolling_mode;
   Bool b_first_char_processed;
   Bool b_start_and_end_pages_diff;
   _MEM_TYPE_SLOW_    U8   char_x_pos;
   /*_MEM_TYPE_MEDFAST_*/ U8   start_page;
   /*_MEM_TYPE_MEDFAST_*/ U8   nb_lines;
   _MEM_TYPE_SLOW_    U8   end_page_ws;

   _MEM_TYPE_SLOW_    U8   height = 0;
   _MEM_TYPE_SLOW_    U8   *p_string;
   _MEM_TYPE_SLOW_    U8   idx_start_char;

   // The 4 following unions "v*" declares variables which are not used at the same time,
   // but in separate code sections. 
   // Thus this enables to save bytes and to get explicit name for these variables
   union
   {
      S8 s8_scroll_width;
      U8 start_page_mask;
   }_MEM_TYPE_SLOW_ v0;

   union
   {
      U8 string_length;
      U8 end_page_mask;
   }_MEM_TYPE_SLOW_ v1;

   union
   {
      U8 curr_page;
      U8 char_width;
   }_MEM_TYPE_SLOW_ v2;

   union
   {
      U8 end_page;
      U8 prev_disp_data;
   }_MEM_TYPE_SLOW_ v3;

   union
   {
      U16 wc;
      U16 char_disp_data;
      U8  width_not_to_draw;
   }v4;

   union
   {
      S16 s;
      U16 u; 
   }_MEM_TYPE_SLOW_ char_acc_width;


   typedef enum
   {
      IN_BETWEEN = 0
   ,  ON_LEFT_ONE
   ,  ON_RIGHT_ONE
   }Pos_bound;

   struct
   {
      struct
      {
         U8        nb_lines;
         U8        mask;
         Pos_bound pos;
      }boundary;

      U8 mask;
   }_MEM_TYPE_SLOW_ scroll;
#endif

   // No string pointed, so exit out of this function
   if( NULL == (void *)string )
      { return; }

   if( ih_g_curr_font == IDC_FONT_08 )
   {
      U8 start_page;
      U8 nb_lines;
      while( *string )
      {
         nb_lines = *string++;
         if( 0 == nb_lines )
            return;
         if(( nb_lines > 0x7F )
            ||( nb_lines < ' ' ))
            continue;
         nb_lines -= ' ';
         for( start_page = 0; start_page < 6; start_page++ )
         {
            Lcd_set_cursor();
            Lcd_write_display_data( ascii8_uncode[ nb_lines ][ start_page ]);
            Lcd_set_line( Lcd_get_line() + 1 );
         }
      }
      return;
   }

   SDKLoadCode( LCD_SSD1303_TEMP_CODE01 );
   lcd_puts_simple( string );
#if 0
   // Default setting
   scroll.mask      = 0xff;
   b_scrolling_mode_effective = FALSE;


   if( ( NULL != ptr_txt_scrolling_prm )
   &&  ( 0xff != ptr_txt_scrolling_prm->idx_start_char ) )
   {
      // Scrolling mode required but can be not effective if text width inferior to viewport width
      b_scrolling_mode = TRUE;
      b_first_char_processed = FALSE;
      idx_start_char = ptr_txt_scrolling_prm->idx_start_char;
      char_acc_width.s = ptr_txt_scrolling_prm->offset_x;
   }
   else
   {
      b_scrolling_mode = FALSE;
      b_first_char_processed = TRUE;
      idx_start_char = 0;
      char_acc_width.s = 0;
   }

   p_string = ( _MEM_TYPE_SLOW_ U8 *)unicode_converter(string);
   string   = (U8 _MEM_TYPE_SLOW_*)p_string;   // "string" keeps the returned unicode buffer address
   p_string = Unicode_get_addr_string(p_string) + idx_start_char*2;


   // Get the start X-coordinate of the first character if "offset_x" were equal to 0
   char_x_pos = Lcd_get_x();


   while( p_string != NULL )
   {
      //v4.wc = *((_MEM_TYPE_SLOW_ U16 *)p_string)++;
      v4.wc = *((_MEM_TYPE_SLOW_ U16 *)p_string);
      p_string++; p_string++;

      if( 0 == v4.wc )
      { // NULL character => end of string detected

         if( 0 == idx_start_char )
         { 
            // All the string has been displayed ( from the first character to the last character)
            // without having reached the viewport right boundary.
            // So this string is not long enough for scrolling.
            
            // Scrolling was required for this string for its first displayed
            if( b_scrolling_mode )
            {
               // No scrolling for the next displays of this string
               ptr_txt_scrolling_prm->idx_start_char = 0xff;
            }
            else
            {
               // All characters of the static string have been displayed
               // Define the last position of the cursor for an eventual next consecutive text display
               lcd_goto_xy( char_x_pos, Lcd_get_y() );
            }

            // Exit out of the loop
            p_string = ( _MEM_TYPE_SLOW_ U8 *)NULL; 
            continue;
         }
         else
         { 
            // Loop on the first character of the string
            p_string = ( _MEM_TYPE_SLOW_ U8 *)Unicode_get_addr_string((UnicodeBuffer*)string);
            idx_start_char = 0;
            continue;
         }
      }

      Ih_open_font_access();

      // Load the height value just once
      if( 0 == height)  
         { height = ih_get_font_height(); }

      // Set pointer on the first character data
      ih_ptr_char( v4.wc );                  

      // Get the width of the character
      v2.char_width  = Ih_get_font_data();


      // Default setting for scrolling mode and not
      scroll.boundary.pos = IN_BETWEEN;
      
      char_acc_width.s += v2.char_width;
      if (char_acc_width.s < 0)
      { // First characters are out of the display area thus no display
         idx_start_char++;
         continue; // Loop on the instruction "while( p_string != NULL )" above
      }

      // Exceptionally, keypad process also executed here because of the long time spent in the dfc abort 
      if( b_scrolling_mode )
      {
        kbd_process();

#if 0//( OID == ENABLE )
         // Scan oid pen
         if( !g_b_storage_bulid_on && b_oid_init_flag )
         {
            scan_oid();
         }
#endif  //#if( OID == ENABLE )

      }

      // Here, "char_acc_width.s" is >= 0
      if( FALSE == b_first_char_processed )
      {
         b_first_char_processed = TRUE;
         ptr_txt_scrolling_prm->offset_x = char_acc_width.s - v2.char_width ;
         ptr_txt_scrolling_prm->idx_start_char = idx_start_char;
      }


      if( (char_x_pos+v2.char_width-1) >= lcd_g_viewport.right_x )
      { // Being on the right boundary, so the left part of the character is only to display
         //Enabling to come out the loop after the display of the last character
         p_string = ( _MEM_TYPE_SLOW_ U8 *)NULL; 
         if( b_scrolling_mode )    { b_scrolling_mode_effective = TRUE; }

         scroll.boundary.nb_lines = 0;
         scroll.mask = 0xFF;

        
         // viewport right must be >= char_x_pos
         if( lcd_g_viewport.right_x < char_x_pos )
            { lcd_g_viewport.right_x = char_x_pos; }
         // Have the width of the left part to draw
         v2.char_width = lcd_g_viewport.right_x - char_x_pos;

         scroll.boundary.pos = ON_RIGHT_ONE; // Indicate the type of processing to apply
      }
      else if( char_acc_width.u <= v2.char_width )
      { // Being on the left boundary, so the right part of the character is only to display
      
         scroll.boundary.nb_lines = v2.char_width - char_acc_width.u;
         scroll.mask = 0xFF;

         // Here the result of "char_acc_width.u - char_width" is always <=0
         // "char_x_pos" gives now the X-coordinate of the first pixel to draw
         char_x_pos += char_acc_width.u - v2.char_width;
 
         // Indicate the type of processing to apply
         scroll.boundary.pos = ON_LEFT_ONE;
      }


      // Define the new position of the cursor to the lcd controller
      lcd_goto_xy( char_x_pos, Lcd_get_y() );


      nb_lines      = lcd_get_nb_lines( v2.char_width );
      // "end_page_ws" gets the index of the end page without shifting-in-page
      end_page_ws   = lcd_get_end_page_ws( height );
      // "v3.end_page" gets the index of the end page with shifting-in-page
      v3.end_page   = lcd_get_end_page(    height );
      // BE CAREFUL : start_page_mask == end_page_mask == 0xff if b_merging set
      v0.start_page_mask = lcd_get_start_page_mask(  height ); 
      v1.end_page_mask   = lcd_get_end_page_mask(    height );
    
 
      b_suppl_page = FALSE;

      if( v3.end_page != end_page_ws )
      { // A supplementary page is required with the shifting-in-page for the display of this picture
         if ( v3.end_page < NB_LCD_PAGES )
         { // The supplementary page is allowed because of no danger of page overflow
            b_suppl_page = TRUE;
         }
      }


      start_page = Lcd_get_page();

      if( ON_LEFT_ONE == scroll.boundary.pos )
      { //Not executed if scrolling mode not actived
         // Offset on display data to not display the left part of the character being on the boundary
         ih_add_font_offset( (end_page_ws-start_page + 1) * scroll.boundary.nb_lines );
         // Calculate the width of the right part of the character to display
         nb_lines -= scroll.boundary.nb_lines;
         // Set x-coordinate position from where the right part of the character begins to be displayed
         lcd_goto_x( char_x_pos + scroll.boundary.nb_lines );
      }


      //Calculate the x-coordinate of the next character to display
      char_x_pos += v2.char_width;


      // KEEP IN MIND : v0.start_page_mask == v1.end_page_mask == 0xff if b_merging set

      if( start_page != end_page_ws )     { b_start_and_end_pages_diff = TRUE;  }
      else                                { b_start_and_end_pages_diff = FALSE; }

      for(; nb_lines != 0; nb_lines--)
      {
         v2.curr_page = start_page;
         Lcd_set_page( v2.curr_page );

         // Get the display data byte of the start page in which the drawing of the picture starts.
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "start_page_mask"
         Lcd_set_cursor();
         //Lcd_dummy_read();
         //Lcd_read_display_data();
         //v3.prev_disp_data = display_data_read & v0.start_page_mask;
         v3.prev_disp_data = display_data_read;
      

         while( 1 )
         {          
            if( v2.curr_page > end_page_ws )    { break; }

            v4.char_disp_data = (U16)( Ih_get_font_data() * Lcd_get_shift_in_page() );
				
            LSB(v4.char_disp_data) |= v3.prev_disp_data;
            LSB(v4.char_disp_data) &= scroll.mask;
            v3.prev_disp_data = MSB(v4.char_disp_data);


            if( v2.curr_page == end_page_ws )
            {
               if( b_start_and_end_pages_diff )
               { // Number of pages > 1
                  if( FALSE == b_suppl_page )
                  { //The picture doesn't require a supplementary building of page,
                    //thus the mixing of the end part of the picture is to do right now
                     v3.prev_disp_data = LSB(v4.char_disp_data);
                     break;
                  }
               }
            }

            /*if( Lcd_is_merging() )
            {
               Lcd_dummy_read();
               Lcd_read_display_data();
               LSB(v4.char_disp_data) |= display_data_read;
            }*/
            Lcd_set_cursor();
            Lcd_write_display_data( LSB(v4.char_disp_data) );
            Lcd_set_line( Lcd_get_line() );
            Lcd_set_page( ++v2.curr_page );
            //Lcd_set_cursor();
         } 


         // Get the display data byte of the end page in which the drawing of the picture ends
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "end_page_mask"
         // The mixing of the end part of the character to display and the background is done here if
         // the number of pages is greater than 1 or a supplementary page exists.
         // Indeed, in the case where the number of pages is 1 and no supplementary page, 
         // this mixing has already be done with the help of the mask "start_page_mask" above.
         if( ( b_start_and_end_pages_diff ) || ( b_suppl_page ) )
         {
            //Lcd_dummy_read();
            //Lcd_read_display_data();
            Lcd_set_cursor();
            //Lcd_write_display_data( (v3.prev_disp_data & scroll.mask) | (display_data_read & v1.end_page_mask) );
            Lcd_write_display_data( (v3.prev_disp_data & scroll.mask) );
         }

         Lcd_set_line( Lcd_get_line()+1 );
      }
      Ih_end_font_access();
   }

   // Set free the pointer used for the scrolling mode
   ptr_txt_scrolling_prm = ( st_txt_scrolling _MEM_TYPE_SLOW_ *)NULL;

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
#endif
}

#if (EMBEDDED_CODE_FONT == ENABLE)
//! @brief lcd_puts_code
//!
//! Display text on the LCD screen from the code character table
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  const U8* string : string to display
//!
//! @return none

// Drawing direction
//      (0,0) __________
//           |          |
//           | |    /|  |
//           | |   / |  |
//           | |  /  |  |
//           | | /   |  |
//           | |/   \|/ |
//           |__________|

void lcd_puts_code( const U8* string )
{
   Bool b_suppl_page;
   Bool b_unicode_string;
   _MEM_TYPE_SLOW_    U8   char_x_pos;
   _MEM_TYPE_MEDFAST_ U8   start_page;
   _MEM_TYPE_MEDFAST_ U8   nb_lines;
   _MEM_TYPE_SLOW_    U8   end_page_ws;
   _MEM_TYPE_SLOW_    U8   height;
   UnicodeBuffer* p_string;
   _MEM_TYPE_SLOW_    U8   start_page_mask;


   // The 4 following unions "v*" declares variables which are not used at the same time,
   // but in separate code sections. 
   // Thus this enables to save bytes and to get explicit name for these variables

   union
   {
      U8 string_length;
      U8 end_page_mask;
   }_MEM_TYPE_SLOW_ v1;

   union
   {
      U8 curr_page;
      U8 char_width;
   }_MEM_TYPE_SLOW_ v2;

   union
   {
      U8 end_page;
      U8 prev_disp_data;
   }_MEM_TYPE_SLOW_ v3;

   union
   {
      U16 wc;
      U16 char_disp_data;
   }v4;


   // No string pointed, so exit out of this function
   if( NULL == string )
      { return; }


   if( Unicode_is_string_of_unicode_buffer(string) )    
   {
      b_unicode_string = TRUE;
      //Point the first character of the unicode string
      p_string = Unicode_get_addr_string(string);
   }
   else
   {
      b_unicode_string = FALSE;
      //Point the first character of the ascii string
      p_string = string;
   }

   Ih_open_code_font_access();
   height = Ih_get_code_font_data();


   // Get the start X-coordinate of the first character if "offset_x" were equal to 0
   char_x_pos = Lcd_get_x();


   while( p_string != NULL )
   {
      if( b_unicode_string )
         { MSB(v4.wc) = *p_string++; LSB(v4.wc) = *p_string++; }
      else
         { v4.wc = *p_string++; }

      if( 0 == v4.wc )
      { // NULL character => end of string detected
         
         // All characters of the static string have been displayed
         // Define the last position of the cursor for an eventual next consecutive text display
         lcd_goto_xy( char_x_pos, Lcd_get_y() );

         // Exit out of the loop
         p_string = NULL; 
         continue;
      }

      ih_ptr_code_char( v4.wc );                  // Set pointer on the data of the character
      v2.char_width  = Ih_get_code_font_data();   // Get the width of this character in pixel unit


      // Define the new position of the cursor to the lcd controller
      lcd_goto_xy( char_x_pos, Lcd_get_y() );


      nb_lines      = lcd_get_nb_lines( v2.char_width );
      // "end_page_ws" gets the index of the end page without shifting-in-page
      end_page_ws   = lcd_get_end_page_ws( height );
      // "v3.end_page" gets the index of the end page with shifting-in-page
      v3.end_page   = lcd_get_end_page(    height );
      // BE CAREFUL : start_page_mask == end_page_mask == 0xff if b_merging set
      start_page_mask    = lcd_get_start_page_mask(  height ); 
      v1.end_page_mask   = lcd_get_end_page_mask(    height );
    
 
      b_suppl_page = FALSE;

      if( v3.end_page != end_page_ws )
      { // A supplementary page is required with the shifting-in-page for the display of this picture
         if ( v3.end_page < NB_LCD_PAGES )
         { // The supplementary page is allowed because of no danger of page overflow
            b_suppl_page = TRUE;
         }
      }
      start_page = Lcd_get_page();

      //Calculate the x-coordinate of the next character to display
      char_x_pos += v2.char_width;

      // KEEP IN MIND : v0.start_page_mask == v1.end_page_mask == 0xff if b_merging set

      for(; nb_lines != 0; nb_lines--)
      {
         v2.curr_page = start_page;
         Lcd_set_page( v2.curr_page );

         // Get the display data byte of the start page in which the drawing of the picture starts.
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "start_page_mask"
         Lcd_set_cursor();
         //Lcd_dummy_read();
         //Lcd_read_display_data();
         //v3.prev_disp_data = display_data_read & start_page_mask;
         v3.prev_disp_data = display_data_read;
      
         while( 1 )
         {          
            if( v2.curr_page > end_page_ws )    { break; }

            v4.char_disp_data = (U16)( Ih_get_code_font_data() * Lcd_get_shift_in_page() );
            LSB(v4.char_disp_data) |= v3.prev_disp_data;
            v3.prev_disp_data = MSB(v4.char_disp_data);


            if( v2.curr_page == end_page_ws )
            {
               if( start_page != end_page_ws )
               { // Number of pages > 1
                  if( FALSE == b_suppl_page )
                  { //The picture doesn't require a supplementary building of page,
                    //thus the mixing of the end part of the picture is to do right now
                     v3.prev_disp_data = LSB(v4.char_disp_data);
                     break;
                  }
               }
            }

            /*if( Lcd_is_merging() )
            {
               Lcd_dummy_read();
               Lcd_read_display_data();
               LSB(v4.char_disp_data) |= display_data_read;
            }*/

            Lcd_write_display_data( LSB(v4.char_disp_data) );
            Lcd_set_line( Lcd_get_line() );
            Lcd_set_page( ++v2.curr_page );
            Lcd_set_cursor();
         } 


         // Get the display data byte of the end page in which the drawing of the picture ends
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "end_page_mask"
         // The mixing of the end part of the character to display and the background is done here if
         // the number of pages is greater than 1 or a supplementary page exists.
         // Indeed, in the case where the number of pages is 1 and no supplementary page, 
         // this mixing has already be done with the help of the mask "start_page_mask" above.
         if( ( start_page != end_page_ws ) || ( TRUE == b_suppl_page ) )
         {
            //Lcd_dummy_read();
            //Lcd_read_display_data();
            //Lcd_write_display_data( (v3.prev_disp_data) | (display_data_read & v1.end_page_mask) );
            Lcd_write_display_data( v3.prev_disp_data );
         }

         Lcd_set_line( Lcd_get_line()+1 );
      }
   }

   Ih_end_code_font_access();

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
}
#endif
#if 0
//! @brief lcd_clear_text_line_area
//!
//! Clear the area reserved in the drawing of a text line
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  U8 x_end : end x-coordinate of the area to clear
//!
//! @return none
void lcd_clear_text_line_area( const U8 x_end )
{
   U8 height;

   Ih_open_font_access();
   height = ih_get_font_height(); //height of the current font
   Ih_end_font_access();

   lcd_clear_part_of_screen( 
        Lcd_get_x()
      , Lcd_get_y()
      , x_end-Lcd_get_x()+1      //width of the area to clear
      , height );
}
#endif

//! @brief lcd_display_screen
//!
//! Display the full screen from the screen buffer
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  none
//!
//! @return void
#if( LCD_SCREEN_BUFFER == ENABLED )
void lcd_display_screen( void )
{
   U8 i_page;
   U8 nb_lines;

   s_ptr_screen_buffer = &s_screen_buffer[0];

   for(i_page = 0; i_page < NB_LCD_PAGES; i_page++)
   {
      Lcd_set_page( i_page );
      Lcd_set_line( 0 );
      Lcd_set_cursor() 

      for( nb_lines = NB_LCD_LINES; nb_lines !=0 ; nb_lines-- )
      {
         /* Waiting display interface available to lauch a writing */
         Lcd_drv_test_lcbusy();
         /* Transmit display data */
         Lcd_drv_write_data( *(s_ptr_screen_buffer++) ); 
      }
   }
}
#endif

//! @brief lcd_turn_on
//!
//! Turn on the power and the display of the lcd
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  none
//!
//! @return none
void lcd_turn_on(void)
{
/*#define Wait_on()    timer = Timer_set_timer(LCD_ON_TIME); \
                        while (!Timer_is_timeout(timer));
   U32 timer;*/
   // Start OLED Power
   Lcd_power_switch_on();
   //Wait_on();
   // Enable display
   //Mcu_set_sfr_page_lcd();

   Lcd_display_on();
   Lcd_set_backlight_on();
   // Disable the backlight timer
   g_timer_backlight = 0;
}

//! @brief lcd_turn_off
//!
//! Turn off the power and the display of the lcd
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param  none
//!
//! @return none
void lcd_turn_off(void)
{                    
/*#define Wait_off()   timer = Timer_set_timer(LCD_OFF_TIME); \
                        while (!Timer_is_timeout(timer));
   U32 timer;*/
   // Disable display
   //Mcu_set_sfr_page_lcd();
   Lcd_display_off();
   Lcd_set_backlight_off();
   //Wait_off();
   // Stop OLED Power
   Lcd_power_switch_off();
}


#pragma CODE = LCD_SSD1303_TEMP_CODE00

//! @brief lcd_init
//!
//! To configurate the display interface and the controller of the LCD device
//!
//! @warning Code:XX bytes (function code length)
//!
//! @param none
//! @return none
//!
void lcd_init(void)
{
#define  Wait_10ms()    timer = Timer_set_timer(TIMER_MS(30)); \
                           while (!Timer_is_timeout(timer));
   U32 timer;

   //Mcu_set_sfr_page_lcd();

   // Set to OFF the backlight
   Lcd_set_backlight_off();

   // Init of the display interface
   lcd_drv_basic_init_interface();

   // Reset the OLED controller
   Lcd_reset_on();
   Wait_10ms();
   Lcd_reset_off();

   //Display off
   lcd_turn_off();

   //Select DC-DC setup
   lcd_write_command( LCD_CMD_DC_DC_SETUP );
   lcd_write_command( LCD_VAL_DC_DC_OFF );

   //Display Duty select
   lcd_write_command( LCD_CMD_DUTY_RATIO );
   lcd_write_command( LCD_VAL_DUTY_RATIO );

   //Display offset
   lcd_write_command( LCD_CMD_DISPLAY_OFFSET );
   lcd_write_command( LCD_VAL_DISPLAY_OFFSET );

   //ADC select directiona
   lcd_write_command( LCD_ADC_NORMAL );
   //lcd_write_command( LCD_ADC_REVERSED );

   //SHL select directional
   //lcd_write_command( LCD_COMMON_OUTPUT_NORMAL );
   lcd_write_command( LCD_COMMON_OUTPUT_REVERSED );

   //set normal display
   lcd_write_command( LCD_DISPLAY_NORMAL );
   //lcd_write_command( LCD_DISPLAY_REVERSED );

   //Set entire display on/off (0xA4:Normal display)
   lcd_write_command( LCD_ENTIRE_DISPLAY_OFF );
  
   //Electronic volume register select
   lcd_write_command( LCD_CMD_ELECTRONIC_VOLUME );
   lcd_write_command( LCD_VAL_DEFAULT_ELEC_VOLUME );

   lcd_write_command( LCD_CMD_BIGHTNESS );
   lcd_write_command( LCD_VAL_BIGHTNESS );
   
   //Frame rate
   lcd_write_command( LCD_CMD_FRAME_RATE );
   lcd_write_command( LCD_VAL_FRAME_RATE );

   //Mode setting
   lcd_write_command( LCD_CMD_SET_MODE );
   lcd_write_command( LCD_VAL_MONO_MODE );
	
   lcd_turn_on();
}


#pragma CODE = LCD_SSD1303_CODE

#if (BACKLIGHT == ENABLE)
//! lcd_rearm_backlight_on
//!
//! Rearm the backlight of the OLED.
//!
//! @param none
//! @return none
//!
void lcd_rearm_backlight_on( void )
{
   if( Lcd_backlight_is_enable() )
   {
      if( g_b_lcd_backlight_off )
      {
         // Turn on the lcd power and display
         lcd_turn_on();
      }
      g_b_lcd_backlight_off = FALSE;

      // Armed the backlight timer
      Lcd_start_backlight_timer();
   }
}

//! lcd_shut_backlight_off
//!
//! Switch-off the OLED.
//!
//! @param none
//! @return none
//!
void lcd_shut_backlight_off( void )
{
   if( Lcd_backlight_is_enable() )
   {
      if( Lcd_is_backlight_timout() )
      {
         Lcd_stop_backlight_timer();
          // Turn off the lcd display and power
         lcd_turn_off();
         //mail_send_event(EVT_BACKLIGHT_OFF, 0);
         g_b_lcd_backlight_off = TRUE;
         g_mmi_lcd_backlight_off = TRUE;
      }  
   }
}
#endif   // (BACKLIGHT == ENABLE)

#if 0
void lcd_set_inverse( Bool v )
{
   lcd_g_inverse = v;
}


void lcd_puts_inverse( U8 *str, Bool inverse )
{
   Bool old;
   old = lcd_g_inverse;
   lcd_set_inverse( inverse );
   lcd_puts( str );
   lcd_set_inverse( old );
}
#endif


#pragma CODE = LCD_SSD1303_TEMP_CODE01

void lcd_puts_simple( U8* string )
{
   Bool b_suppl_page;
   Bool b_scrolling_mode;
   Bool b_first_char_processed;
   Bool b_start_and_end_pages_diff;
   _MEM_TYPE_SLOW_    U8   char_x_pos;
   /*_MEM_TYPE_MEDFAST_*/ U8   start_page;
   /*_MEM_TYPE_MEDFAST_*/ U8   nb_lines;
   _MEM_TYPE_SLOW_    U8   end_page_ws;

   _MEM_TYPE_SLOW_    U8   height = 0;
   U8   _MEM_TYPE_SLOW_    *p_string;
   _MEM_TYPE_SLOW_    U8   idx_start_char;

   // The 4 following unions "v*" declares variables which are not used at the same time,
   // but in separate code sections. 
   // Thus this enables to save bytes and to get explicit name for these variables
   union
   {
      S8 s8_scroll_width;
      U8 start_page_mask;
   }_MEM_TYPE_SLOW_ v0;

   union
   {
      U8 string_length;
      U8 end_page_mask;
   }_MEM_TYPE_SLOW_ v1;

   union
   {
      U8 curr_page;
      U8 char_width;
   }_MEM_TYPE_SLOW_ v2;

   union
   {
      U8 end_page;
      U8 prev_disp_data;
   }_MEM_TYPE_SLOW_ v3;

   union
   {
      U16 wc;
      U16 char_disp_data;
      U8  width_not_to_draw;
   }v4;

   union
   {
      S16 s;
      U16 u; 
   }_MEM_TYPE_SLOW_ char_acc_width;


   typedef enum
   {
      IN_BETWEEN = 0
   ,  ON_LEFT_ONE
   ,  ON_RIGHT_ONE
   }Pos_bound;

   struct
   {
      struct
      {
         U8        nb_lines;
         U8        mask;
         Pos_bound pos;
      }boundary;

      U8 mask;
   }_MEM_TYPE_SLOW_ scroll;


   // No string pointed, so exit out of this function
   if( NULL == (void *)string )
      { return; }


   // Default setting
   scroll.mask      = 0xff;
   b_scrolling_mode_effective = FALSE;


   if( ( NULL != ptr_txt_scrolling_prm )
   &&  ( 0xff != ptr_txt_scrolling_prm->idx_start_char ) )
   {
      // Scrolling mode required but can be not effective if text width inferior to viewport width
      b_scrolling_mode = TRUE;
      b_first_char_processed = FALSE;
      idx_start_char = ptr_txt_scrolling_prm->idx_start_char;
      char_acc_width.s = ptr_txt_scrolling_prm->offset_x;
   }
   else
   {
      b_scrolling_mode = FALSE;
      b_first_char_processed = TRUE;
      idx_start_char = 0;
      char_acc_width.s = 0;
   }

   SDKLoadCode( UNICODE_TEMP_CODE03 );
   p_string = (U8 _MEM_TYPE_SLOW_  *)unicode_converter(string);
   string   = (U8 _MEM_TYPE_SLOW_*)p_string;   // "string" keeps the returned unicode buffer address
   p_string = Unicode_get_addr_string(p_string) + idx_start_char*2;


   // Get the start X-coordinate of the first character if "offset_x" were equal to 0
   char_x_pos = Lcd_get_x();


   while( p_string != NULL )
   {
      //v4.wc = *((_MEM_TYPE_SLOW_ U16 *)p_string)++;
      v4.wc = *(( U16 _MEM_TYPE_SLOW_ *)p_string);
      p_string++; p_string++;

      if( 0 == v4.wc )
      { // NULL character => end of string detected

         if( 0 == idx_start_char )
         { 
            // All the string has been displayed ( from the first character to the last character)
            // without having reached the viewport right boundary.
            // So this string is not long enough for scrolling.
            
            // Scrolling was required for this string for its first displayed
            if( b_scrolling_mode )
            {
               // No scrolling for the next displays of this string
               ptr_txt_scrolling_prm->idx_start_char = 0xff;
            }
            else
            {
               // All characters of the static string have been displayed
               // Define the last position of the cursor for an eventual next consecutive text display
               lcd_goto_xy( char_x_pos, Lcd_get_y() );
            }

            // Exit out of the loop
            p_string = ( U8 _MEM_TYPE_SLOW_ *)NULL; 
            continue;
         }
         else
         { 
            // Loop on the first character of the string
            p_string = ( U8 _MEM_TYPE_SLOW_ *)Unicode_get_addr_string((UnicodeBuffer*)string);
            idx_start_char = 0;
            continue;
         }
      }

      SDKLoadCode( IMG_HANDLER_TEMP_CODE00 );
      Ih_open_font_access();

      // Load the height value just once
      if( 0 == height)  
         { height = ih_get_font_height(); }

      // Set pointer on the first character data
      ih_ptr_char( v4.wc );                  

      // Get the width of the character
      v2.char_width  = Ih_get_font_data();


      // Default setting for scrolling mode and not
      scroll.boundary.pos = IN_BETWEEN;
      
      char_acc_width.s += v2.char_width;
      if (char_acc_width.s < 0)
      { // First characters are out of the display area thus no display
         idx_start_char++;
         continue; // Loop on the instruction "while( p_string != NULL )" above
      }

      // Exceptionally, keypad process also executed here because of the long time spent in the dfc abort 
      /*if( b_scrolling_mode )
      {
        kbd_process();

#if 0//( OID == ENABLE )
         // Scan oid pen
         if( !g_b_storage_bulid_on && b_oid_init_flag )
         {
            scan_oid();
         }
#endif  //#if( OID == ENABLE )

      }*/

      // Here, "char_acc_width.s" is >= 0
      if( FALSE == b_first_char_processed )
      {
         b_first_char_processed = TRUE;
         ptr_txt_scrolling_prm->offset_x = char_acc_width.s - v2.char_width ;
         ptr_txt_scrolling_prm->idx_start_char = idx_start_char;
      }


      if( (char_x_pos+v2.char_width-1) >= lcd_g_viewport.right_x )
      { // Being on the right boundary, so the left part of the character is only to display
         //Enabling to come out the loop after the display of the last character
         p_string = ( U8 _MEM_TYPE_SLOW_ *)NULL; 
         if( b_scrolling_mode )    { b_scrolling_mode_effective = TRUE; }

         scroll.boundary.nb_lines = 0;
         scroll.mask = 0xFF;

        
         // viewport right must be >= char_x_pos
         if( lcd_g_viewport.right_x < char_x_pos )
            { lcd_g_viewport.right_x = char_x_pos; }
         // Have the width of the left part to draw
         v2.char_width = lcd_g_viewport.right_x - char_x_pos;

         scroll.boundary.pos = ON_RIGHT_ONE; // Indicate the type of processing to apply
      }
      else if( char_acc_width.u <= v2.char_width )
      { // Being on the left boundary, so the right part of the character is only to display
      
         scroll.boundary.nb_lines = v2.char_width - char_acc_width.u;
         scroll.mask = 0xFF;

         // Here the result of "char_acc_width.u - char_width" is always <=0
         // "char_x_pos" gives now the X-coordinate of the first pixel to draw
         char_x_pos += char_acc_width.u - v2.char_width;
 
         // Indicate the type of processing to apply
         scroll.boundary.pos = ON_LEFT_ONE;
      }


      // Define the new position of the cursor to the lcd controller
      lcd_goto_xy( char_x_pos, Lcd_get_y() );


      nb_lines      = lcd_get_nb_lines( v2.char_width );
      // "end_page_ws" gets the index of the end page without shifting-in-page
      end_page_ws   = lcd_get_end_page_ws( height );
      // "v3.end_page" gets the index of the end page with shifting-in-page
      v3.end_page   = lcd_get_end_page(    height );
      // BE CAREFUL : start_page_mask == end_page_mask == 0xff if b_merging set
      v0.start_page_mask = lcd_get_start_page_mask(  height ); 
      v1.end_page_mask   = lcd_get_end_page_mask(    height );
    
 
      b_suppl_page = FALSE;

      if( v3.end_page != end_page_ws )
      { // A supplementary page is required with the shifting-in-page for the display of this picture
         if ( v3.end_page < NB_LCD_PAGES )
         { // The supplementary page is allowed because of no danger of page overflow
            b_suppl_page = TRUE;
         }
      }


      start_page = Lcd_get_page();

      if( ON_LEFT_ONE == scroll.boundary.pos )
      { //Not executed if scrolling mode not actived
         // Offset on display data to not display the left part of the character being on the boundary
         ih_add_font_offset( (end_page_ws-start_page + 1) * scroll.boundary.nb_lines );
         // Calculate the width of the right part of the character to display
         nb_lines -= scroll.boundary.nb_lines;
         // Set x-coordinate position from where the right part of the character begins to be displayed
         lcd_goto_x( char_x_pos + scroll.boundary.nb_lines );
      }


      //Calculate the x-coordinate of the next character to display
      char_x_pos += v2.char_width;


      // KEEP IN MIND : v0.start_page_mask == v1.end_page_mask == 0xff if b_merging set

      if( start_page != end_page_ws )     { b_start_and_end_pages_diff = TRUE;  }
      else                                { b_start_and_end_pages_diff = FALSE; }

      for(; nb_lines != 0; nb_lines--)
      {
         v2.curr_page = start_page;
         Lcd_set_page( v2.curr_page );

         // Get the display data byte of the start page in which the drawing of the picture starts.
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "start_page_mask"
         Lcd_set_cursor();
         //Lcd_dummy_read();
         //Lcd_read_display_data();
         //v3.prev_disp_data = display_data_read & v0.start_page_mask;
         v3.prev_disp_data = display_data_read;
      

         while( 1 )
         {          
            if( v2.curr_page > end_page_ws )    { break; }

            v4.char_disp_data = (U16)( Ih_get_font_data() * Lcd_get_shift_in_page() );
				
            LSB(v4.char_disp_data) |= v3.prev_disp_data;
            LSB(v4.char_disp_data) &= scroll.mask;
            v3.prev_disp_data = MSB(v4.char_disp_data);


            if( v2.curr_page == end_page_ws )
            {
               if( b_start_and_end_pages_diff )
               { // Number of pages > 1
                  if( FALSE == b_suppl_page )
                  { //The picture doesn't require a supplementary building of page,
                    //thus the mixing of the end part of the picture is to do right now
                     v3.prev_disp_data = LSB(v4.char_disp_data);
                     break;
                  }
               }
            }

            /*if( Lcd_is_merging() )
            {
               Lcd_dummy_read();
               Lcd_read_display_data();
               LSB(v4.char_disp_data) |= display_data_read;
            }*/
            Lcd_set_cursor();
            Lcd_write_display_data( LSB(v4.char_disp_data) );
            Lcd_set_line( Lcd_get_line() );
            Lcd_set_page( ++v2.curr_page );
            //Lcd_set_cursor();
         } 


         // Get the display data byte of the end page in which the drawing of the picture ends
         // As a pixel shifting can exist, a part of the display data byte can be cleared to paste
         // the picture by a OR operation.
         // The clearing of these bits is done with the help of the mask "end_page_mask"
         // The mixing of the end part of the character to display and the background is done here if
         // the number of pages is greater than 1 or a supplementary page exists.
         // Indeed, in the case where the number of pages is 1 and no supplementary page, 
         // this mixing has already be done with the help of the mask "start_page_mask" above.
         if( ( b_start_and_end_pages_diff ) || ( b_suppl_page ) )
         {
            //Lcd_dummy_read();
            //Lcd_read_display_data();
            Lcd_set_cursor();
            //Lcd_write_display_data( (v3.prev_disp_data & scroll.mask) | (display_data_read & v1.end_page_mask) );
            Lcd_write_display_data( (v3.prev_disp_data & scroll.mask) );
         }

         Lcd_set_line( Lcd_get_line()+1 );
      }
      Ih_end_font_access();
   }

   // Set free the pointer used for the scrolling mode
   ptr_txt_scrolling_prm = ( st_txt_scrolling _MEM_TYPE_SLOW_ *)NULL;

   // Require the display of the new built screen
   Lcd_new_screen_to_display();
}

#endif   // #if ( LCD_CONTROLLER_PART_NUMBER == LCD_CONTROLLER_SSD1303 )

#else

#endif   //#if( LCD_PRESENT == ENABLED )

#endif   // _lcd_SSD1303_c
