
#ifndef _BINARY_IMAGE_H_
	#define _BINARY_IMAGE_H_
	//------------------------
	#define C_OPEN         0
	#define C_OID          1
	#define C_MP3          2
	#define C_REC_PASTER   4
	#define C_DIC          7
	#define C_POWEROFF     9
	#define C_UPGRADE      10
	#define C_CAB          11
	#define C_USB          12
	#define C_READBNL      14
	#define C_WIRELESS_OID 15
	#define C_UPGBURNSPI   17
	#define D_CAB          133
	#define D_WIRE_LESS    134
	#define D_DATA         135
	#define D_OID          136
	//------------------------
#endif
