/******************************************************************************
** Copyright (c) 2009
** King Billion Electronics Co., Ltd
** http://www.kingb.com.tw
******************************************************************************/
#ifndef _FSCONFIG_KBDM9_INTERNAL_H_
#define _FSCONFIG_KBDM9_INTERNAL_H_
#include <KBDM9_DDK.H>
#include <FS.H>

#define FOPEN_MAX 	5    // Define maxima open file

#endif // for _FSCONFIG_KBDM9_INTERNAL_H_
//=============================================================================
// END OF FILE
//=============================================================================