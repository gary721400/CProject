﻿此FW存储于NOR中，数据存储于SD卡中；
小布奇的fw（unicode码）
20BSR_OID4_1202(gary_140625_t4).wingedmonkey
修改：
    1，usb适配器下，有的不能亮充电灯号的问题
20BSR_OID4_1162(gary_131203_t3).wingedmonkey
修改：
	1，加密了lce文件

20BCSR_OID4_1142(120220_t1)
修改：
	1，file patch.c
	2,更新了sdlib，audiolib
	3，更改待机时间为30mA10CSR_K91242(110425_t1)
修改：
	1，修改了上次所提问题

A10CSR_K91242(110425_t1)
修改：
	1，修改了上次所提问题


A10CSR_K91242(110307_t1)
修改：
	1，灯号闪烁快慢
	2，DAC_ENABLE_HEADPHONE的开启调整

A10CSR_K91232(0126_t1)
修改：
	1，录音加入AGC功能代码！


0903_t3:
修改了：
	1，开机就初始化ADC
	2，缩短开机时间大约为3秒
	3，修改了paster模式下，能在录音过程中更改录音文件长度的问题；取消了原来录音文件限制长度的问题
	
